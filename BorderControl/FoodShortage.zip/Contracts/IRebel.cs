﻿namespace BorderControl.Contracts
{
    interface IRebel : IPerson
    {
        string Group { get; }
    }
}
