﻿namespace BorderControl.Core
{
    interface IEngine
    {
        void Run();
    }
}
