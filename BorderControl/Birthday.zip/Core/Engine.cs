﻿namespace BorderControl.Core
{
    using System;
    using System.Linq;
    using BorderControl.IO.Contracts;
    using BorderControl.Models;
    using System.Collections.Generic;
    using BorderControl.Contracts;
    using BorderControl.IO.Models;

    class Engine : IEngine
    {
        private List<ICitizen> citizens;

        private IReadable reader;
        private IWritable writer;
        private Engine()
        {
            this.citizens = new List<ICitizen>();
        }

        public Engine(IReadable reader, IWritable writer)
            : this()
        {
            this.reader = reader;
            this.writer = writer;
        }
        public void Run()
        {
            string command;
            while ((command = reader.ReadLine()) != "End")
            {
                try
                {
                    GetAllInfo(command);
                }
                catch (ArgumentException msg)
                {
                    writer.WriteLine(msg.Message);
                }
            }

            var lastCommand = reader.ReadLine();

            var finalOutput = this.citizens
                .Where(c => c.Birthdate.EndsWith(lastCommand))
                .ToArray();

            foreach (var citizen in finalOutput)
            {
                writer.WriteLine(citizen.Birthdate);
            }
        }

        private void GetAllInfo(string command)
        {
            var arg = command
                .Split(' ', StringSplitOptions.RemoveEmptyEntries)
                .ToArray();

            if (arg[0] == "Citizen")
            {
                GetIdentifiablePerson(arg);
            }
            else if (arg[0] == "Pet")
            {
                GetPet(arg);
            }
        }

        private void GetPet(string[] arg)
        {
            var name = arg[1];
            var birthdate = arg[2];

            var pet = new Pet(name, birthdate);

            this.citizens.Add(pet);
        }

        private void GetIdentifiablePerson(string[] arg)
        {
            var name = arg[1];
            var age = int.Parse(arg[2]);
            var id = arg[3];
            var birthdate = arg[4];

            var person = new Person(name, age, id, birthdate);

            this.citizens.Add(person);
        }
    }
}
