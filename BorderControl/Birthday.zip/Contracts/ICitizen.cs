﻿namespace BorderControl.Contracts
{
    interface ICitizen
    {
        string Name { get; }

        string Birthdate { get; }
    }
}
