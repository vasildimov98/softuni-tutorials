﻿using System.Runtime.CompilerServices;

namespace BorderControl.Contracts
{
    public interface IIdentifable
    {
        string Id { get; }
    }
}
