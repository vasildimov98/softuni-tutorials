﻿namespace BorderControl.IO.Contracts
{
    interface IReadable
    {
        string ReadLine();
    }
}
