﻿namespace BorderControl.Contracts
{
    public interface IRobot : IIdentifable
    {
        public string Model { get; }
    }
}
