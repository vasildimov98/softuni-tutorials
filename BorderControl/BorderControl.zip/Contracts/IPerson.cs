﻿namespace BorderControl.Contracts
{
    public interface IPerson : IIdentifable
    {
        public string Name { get;}
        public int Age { get; }
    }
}
