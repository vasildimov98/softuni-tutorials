﻿namespace BorderControl.Core
{
    using System;
    using System.Linq;
    using BorderControl.IO.Contracts;
    using BorderControl.Models;
    using System.Collections.Generic;
    using BorderControl.Contracts;

    class Engine : IEngine
    {
        private List<IIdentifable> identifables;

        private IReadable reader;
        private IWritable writer;
        private Engine()
        {
            this.identifables = new List<IIdentifable>();
        }

        public Engine(IReadable reader, IWritable writer)
            : this()
        {
            this.reader = reader;
            this.writer = writer;
        }
        public void Run()
        {
            string command;
            while ((command = reader.ReadLine()) != "End")
            {
                try
                {
                    GetAllInfo(command);
                }
                catch (ArgumentException msg)
                {
                    writer.WriteLine(msg.Message);
                }
            }

            var lastCommand = reader.ReadLine();

            var finalOutput = this.identifables
                .Where(id => id.Id.EndsWith(lastCommand))
                .ToArray();

            foreach (var id in finalOutput)
            {
                writer.WriteLine(id.ToString());
            }
        }

        private void GetAllInfo(string command)
        {
            var arg = command
                .Split(' ', StringSplitOptions.RemoveEmptyEntries)
                .ToArray();

            if (arg.Length == 3)
            {
                GetIdentifiablePersom(arg);
            }
            else if (arg.Length == 2)
            {
                GetIdentifabeRobot(arg);
            }
            else
            {
                throw new ArgumentException();
            }
        }

        private void GetIdentifabeRobot(string[] arg)
        {
            var model = arg[0];
            var id = arg[1];

            var robot = new Robot(model, id);

            this.identifables.Add(robot);
        }

        private void GetIdentifiablePersom(string[] arg)
        {
            var name = arg[0];
            var age = int.Parse(arg[1]);
            var id = arg[2];

            var person = new Person(name, age, id);

            this.identifables.Add(person);
        }
    }
}
