﻿namespace Telephony.IO.Contracts
{
    public interface IReadable
    {
        public string ReadLine();
    }
}
