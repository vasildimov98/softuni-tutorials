﻿namespace _02.Data.Models
{
    public class StoreClient : BaseEntity
    {
        public StoreClient(int id, int? parentId)
            : base(id, parentId)
        {
        }
    }
}
