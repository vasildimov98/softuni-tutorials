﻿namespace Tree
{
    using System;
    using System.Linq;
    using System.Text;
    using System.Collections.Generic;

    public class Tree<T> : IAbstractTree<T>
    {
        private readonly List<Tree<T>> children;

        public Tree(T key)
        {
            this.Key = key;

            this.children = new List<Tree<T>>();
        }

        public Tree(T key, params Tree<T>[] children)
            : this(key)
        {
            foreach (var child in children)
            {
                this.AddChild(child);
                this.AddParent(this);
            }
        }

        public T Key { get; private set; }

        public Tree<T> Parent { get; private set; }

        public IReadOnlyCollection<Tree<T>> Children
            => this.children.AsReadOnly();

        public void AddChild(Tree<T> child)
        {
            this.children.Add(child);
        }

        public void AddParent(Tree<T> parent)
        {
            this.Parent = parent;
        }

        public string GetAsString()
        {
            var treeAsString = new StringBuilder();
            var whiteSpaceCount = 0;
            this.DfsOrder(treeAsString, this, whiteSpaceCount);
            return treeAsString.ToString().TrimEnd();
        }

        public List<T> GetLeafKeys()
        {
            var queue = new Queue<Tree<T>>();
            queue.Enqueue(this);

            var leafNodes = new List<T>();

            while (queue.Any())
            {
                var currNode = queue.Dequeue();

                if (this.CheckIfNodeIsLeaf(currNode))
                {
                    leafNodes.Add(currNode.Key);
                }

                foreach (var child in currNode.Children)
                {
                    queue.Enqueue(child);
                }
            }

            return leafNodes.OrderBy(x => x).ToList();
        }

        public List<T> GetMiddleKeys()
        {
            var middleNodes = new List<T>();
            this.DfsOrder(middleNodes, this);
            return middleNodes.OrderBy(x => x).ToList();
        }

        private void DfsOrder(List<T> middleNodes, Tree<T> tree)
        {
            foreach (var child in tree.Children)
            {
                this.DfsOrder(middleNodes, child);
            }

            if (this.CheckIfNodeIsMiddle(tree))
            {
                middleNodes.Add(tree.Key);
            }
        }

        public Tree<T> GetDeepestLeftomostNode()
        {
            throw new NotImplementedException();
        }

        public List<T> GetLongestPath()
        {
            throw new NotImplementedException();
        }

        public List<List<T>> PathsWithGivenSum(int sum)
        {
            throw new NotImplementedException();
        }

        public List<Tree<T>> SubTreesWithGivenSum(int sum)
        {
            throw new NotImplementedException();
        }

        private bool CheckIfNodeIsMiddle(Tree<T> tree)
        {
            return tree.Parent != null && tree.Children.Any();
        }

        private bool CheckIfNodeIsLeaf(Tree<T> currNode)
        {
            return !currNode.children.Any();
        }

        private void DfsOrder(StringBuilder sb, Tree<T> tree, int whiteSpace)
        {
            sb.AppendLine($"{new string(' ', whiteSpace)}{tree.Key}");

            foreach (var child in tree.Children)
            {
                this.DfsOrder(sb, child, whiteSpace + 2);
            }
        }
    }
}
