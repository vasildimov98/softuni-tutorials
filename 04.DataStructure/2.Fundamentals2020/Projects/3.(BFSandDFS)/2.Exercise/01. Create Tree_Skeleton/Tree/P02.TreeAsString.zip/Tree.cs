﻿namespace Tree
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    public class Tree<T> : IAbstractTree<T>
    {
        private readonly List<Tree<T>> children;

        public Tree(T key)
        {
            this.Key = key;

            this.children = new List<Tree<T>>();
        }

        public Tree(T key, params Tree<T>[] children)
            : this(key)
        {
            foreach (var child in children)
            {
                this.AddChild(child);
                this.AddParent(this);
            }
        }

        public T Key { get; private set; }

        public Tree<T> Parent { get; private set; }


        public IReadOnlyCollection<Tree<T>> Children
            => this.children.AsReadOnly();

        public void AddChild(Tree<T> child)
        {
            this.children.Add(child);
        }

        public void AddParent(Tree<T> parent)
        {
            this.Parent = parent;
        }

        public string GetAsString()
        {
            var treeAsString = new StringBuilder();
            var whiteSpaceCount = 0;
            this.DfsOrder(treeAsString, this, whiteSpaceCount);
            return treeAsString.ToString().TrimEnd();
        }

        private void DfsOrder(StringBuilder sb, Tree<T> tree, int whiteSpace)
        {
            sb.AppendLine($"{new string(' ', whiteSpace)}{tree.Key}");

            foreach (var child in tree.Children)
            {
                this.DfsOrder(sb, child, whiteSpace + 2);
            }
        }

        public Tree<T> GetDeepestLeftomostNode()
        {
            throw new NotImplementedException();
        }

        public List<T> GetLeafKeys()
        {
            throw new NotImplementedException();
        }

        public List<T> GetMiddleKeys()
        {
            throw new NotImplementedException();
        }

        public List<T> GetLongestPath()
        {
            throw new NotImplementedException();
        }

        public List<List<T>> PathsWithGivenSum(int sum)
        {
            throw new NotImplementedException();
        }

        public List<Tree<T>> SubTreesWithGivenSum(int sum)
        {
            throw new NotImplementedException();
        }
    }
}
