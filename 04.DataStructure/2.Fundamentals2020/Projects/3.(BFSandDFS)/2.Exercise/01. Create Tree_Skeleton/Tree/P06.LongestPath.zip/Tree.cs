﻿namespace Tree
{
    using System;
    using System.Linq;
    using System.Text;
    using System.Collections.Generic;
    using System.Runtime.CompilerServices;

    public class Tree<T> : IAbstractTree<T>
    {
        private readonly List<Tree<T>> children;

        public Tree(T key)
        {
            this.Key = key;

            this.children = new List<Tree<T>>();
        }

        public Tree(T key, params Tree<T>[] children)
            : this(key)
        {
            foreach (var child in children)
            {
                this.AddChild(child);
                this.AddParent(this);
            }
        }

        public T Key { get; private set; }

        public Tree<T> Parent { get; private set; }

        public IReadOnlyCollection<Tree<T>> Children
            => this.children.AsReadOnly();

        public void AddChild(Tree<T> child)
        {
            this.children.Add(child);
        }

        public void AddParent(Tree<T> parent)
        {
            this.Parent = parent;
        }

        public string GetAsString()
        {
            var treeAsString = new StringBuilder();
            var whiteSpaceCount = 0;
            this.DfsOrder(treeAsString, this, whiteSpaceCount);
            return treeAsString.ToString().TrimEnd();
        }

        public List<T> GetLeafKeys()
        {
            var queue = new Queue<Tree<T>>();
            queue.Enqueue(this);

            var leafNodes = new List<T>();

            while (queue.Any())
            {
                var currNode = queue.Dequeue();

                if (this.CheckIfNodeIsLeaf(currNode))
                {
                    leafNodes.Add(currNode.Key);
                }

                foreach (var child in currNode.Children)
                {
                    queue.Enqueue(child);
                }
            }

            return leafNodes.OrderBy(x => x).ToList();
        }

        public List<T> GetMiddleKeys()
        {
            bool predicate(Tree<T> tree)
                => this.CheckIfNodeIsMiddle(tree);

            var middleNodes = new List<T>();
            this.DfsOrder(middleNodes, this, predicate);
            return middleNodes.OrderBy(x => x).ToList();
        }

        public Tree<T> GetDeepestLeftomostNode()
        {
            bool predicate(Tree<T> tree)
                => this.CheckIfNodeIsLeaf(tree);

            var leafs = new List<Tree<T>>(); 
            this.DfsOrder(leafs, this, predicate);

            var deepestLeftMostNode = this;
            var currDepth = 0;
            foreach (var leaf in leafs)
            {
                var currNodeDepth = this.GetNodeDepth(leaf);

                if (currDepth < currNodeDepth)
                {
                    currDepth = currNodeDepth;
                    deepestLeftMostNode = leaf;
                }
            }
            
            return deepestLeftMostNode;
        }

        private int GetNodeDepth(Tree<T> node)
        {
            var depth = 0;
            while (node.Parent != null)
            {
                depth++;
                node = node.Parent;
            }

            return depth;
        }

        public List<T> GetLongestPath()
        {
            var stack = new Stack<T>();
            var deepestNode = this.GetDeepestLeftomostNode();
            GetStackOfThePath(stack, deepestNode);

            return new List<T>(stack);
        }

        private static void GetStackOfThePath(Stack<T> longestPath, Tree<T> deepestNode)
        {
            while (deepestNode != null)
            {
                longestPath.Push(deepestNode.Key);
                deepestNode = deepestNode.Parent;
            }
        }

        public List<List<T>> PathsWithGivenSum(int sum)
        {
            throw new NotImplementedException();
        }

        public List<Tree<T>> SubTreesWithGivenSum(int sum)
        {
            throw new NotImplementedException();
        }

        private bool CheckIfNodeIsMiddle(Tree<T> tree)
        {
            return tree.Parent != null && tree.Children.Any();
        }

        private bool CheckIfNodeIsLeaf(Tree<T> currNode)
        {
            return !currNode.children.Any();
        }

        private void DfsOrder(List<T> wantedNodes, Tree<T> tree, Predicate<Tree<T>> predicate)
        {
            foreach (var child in tree.Children)
            {
                this.DfsOrder(wantedNodes, child, predicate);
            }

            if (predicate(tree))
            {
                wantedNodes.Add(tree.Key);
            }
        }

        private void DfsOrder(List<Tree<T>> wantedNodes, Tree<T> tree, Predicate<Tree<T>> predicate)
        {
            foreach (var child in tree.Children)
            {
                this.DfsOrder(wantedNodes, child, predicate);
            }

            if (predicate(tree))
            {
                wantedNodes.Add(tree);
            }
        }

        private void DfsOrder(StringBuilder sb, Tree<T> tree, int whiteSpace)
        {
            sb.AppendLine($"{new string(' ', whiteSpace)}{tree.Key}");

            foreach (var child in tree.Children)
            {
                this.DfsOrder(sb, child, whiteSpace + 2);
            }
        }
    }
}
