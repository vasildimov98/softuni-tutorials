﻿namespace Tree
{
    using System;

    public class StartUp
    {
        public static void Main()
        {
            // 7 - 19 - 1, 12, 31, 21, 14 - 23, 6

            var tree =
                new Tree.Tree<int>(7,
                    new Tree<int>(9,
                        new Tree<int>(1),
                        new Tree<int>(12),
                        new Tree<int>(31)),
                    new Tree<int>(21),
                    new Tree<int>(14,
                        new Tree<int>(8),
                        new Tree<int>(6)));
            // BFS order
            var orderedTreeByBFS = tree.OrderBfs();

            Console.WriteLine(string.Join(", ", orderedTreeByBFS));

            Console.WriteLine();

            // Recursion 
            Recursion(15);

            // DFS order
            var orderedTreeByDFS = tree.OrderDfs();
            Console.WriteLine(string.Join(", ", orderedTreeByDFS));
        }

        private static void Recursion(int number)
        {
            if (number == 0)
            {
                return;
            }

            Recursion(number - 1);
            Console.WriteLine(number);
        }
    }
}
