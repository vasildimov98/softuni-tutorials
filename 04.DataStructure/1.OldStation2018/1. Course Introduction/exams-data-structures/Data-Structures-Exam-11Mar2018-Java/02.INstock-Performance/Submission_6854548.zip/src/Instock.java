

import java.util.*;
import java.util.stream.Collectors;

public class Instock implements ProductStock {

    List<Product> productList = new ArrayList<>();
    Set<Product> productSet = new HashSet<>();
    TreeMap<String, Product> byLabel = new TreeMap<>();
    Map<String, Product> byOrder = new LinkedHashMap<>();
    Map<Double, Product> byPrice = new TreeMap<>(Collections.reverseOrder());

    @Override
    public int getCount() {
        return productList.size();
    }

    @Override
    public boolean contains(Product product) {
        return productSet.contains(product);
    }

    @Override
    public void add(Product product) {
        productList.add(product);
        productSet.add(product);
        byLabel.put(product.getLabel(), product);
        byOrder.put(product.getLabel(), product);
        byPrice.put(product.getPrice(), product);
    }

    @Override
    public void changeQuantity(String product, int quantity) {
        if(byOrder.containsKey(product)) {
            byOrder.get(product).setQuantity(quantity);
            Product p = byOrder.remove(product);
            byOrder.put(product, p);
        }
        else
            throw new IllegalArgumentException();
//        for (Product product1 : productList) {
//            if (product1.getLabel().equals(product)) {
//                product1.setQuantity(quantity);
//                productList.remove(product1);
//                productList.add(product1);
//                return;
//            }
//        }
    }

    @Override
    public Product find(int index) {
        return productList.get(index);
    }

    @Override
    public Product findByLabel(String label) {
        if(byLabel.get(label) != null)
            return byLabel.get(label);
        else
            throw new IllegalArgumentException();
    }

    @Override
    public Iterable<Product> findFirstByAlphabeticalOrder(int count) {
        if(productList.size() < count)
            throw new IllegalArgumentException();
        return productList.stream().sorted((x1, x2) -> x1.getLabel()
                .compareTo(x2.getLabel())).limit(count).collect(Collectors.toList());
    }

    @Override
    public Iterable<Product> findAllInRange(double lo, double hi) {
        return productList.stream().filter(product -> product.getPrice() > lo && product.getPrice() <= hi)
                .sorted((x1, x2) -> Double.compare(x2.getPrice(), x1.getPrice())).collect(Collectors.toList());
    }

    @Override
    public Iterable<Product> findAllByPrice(double price) {
        return productList.stream().filter(product -> product.getPrice() == price).collect(Collectors.toList());
    }

    @Override
    public Iterable<Product> findFirstMostExpensiveProducts(int count) {
        if(productList.size() < count)
            throw new IllegalArgumentException();
        return byOrder.values().stream().limit(count).collect(Collectors.toList());
    }

    @Override
    public Iterable<Product> findAllByQuantity(int quantity) {
        return productList.stream().filter(product -> product.getQuantity() == quantity).collect(Collectors.toList());
    }

    @Override
    public Iterator<Product> iterator() {
        return productList.iterator();
    }
}
