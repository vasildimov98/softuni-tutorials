
import java.util.*;
import java.util.stream.Collectors;

public class ThreadExecutor implements Scheduler {

    private Map<Integer, Task> tasksById;
    private Map<Priority, SortedMap<Integer, Task>> tasksByPriority;
    private SortedMap<Integer, SortedMap<Integer, Task>> tasksByConsumptionRate;

    public ThreadExecutor() {
        this.tasksById = new LinkedHashMap<>();
        this.tasksByPriority = new HashMap<>();
        this.tasksByConsumptionRate = new TreeMap<>();

        for (Priority priority : Priority.values()) {
            tasksByPriority.put(priority, new TreeMap<>(Comparator.reverseOrder()));
        }
    }

    public int getCount() {
        return this.tasksById.size();
    }

    public void execute(Task t) {
        if (this.tasksById.containsKey(t.getId())) {
            throw new IllegalArgumentException();
        }

        this.tasksById.put(t.getId(), t);
        this.tasksByPriority.get(t.getTaskPriority()).put(t.getId(), t);
        this.tasksByConsumptionRate.putIfAbsent(t.getConsumption(), new TreeMap<>());
        this.tasksByConsumptionRate.get(t.getConsumption()).put(t.getId(), t);
    }

    public boolean contains(Task t) {
        return this.tasksById.containsKey(t.getId());
    }

    public Task getById(int id) {
        if (!this.tasksById.containsKey(id)) {
            throw new IllegalArgumentException();
        }
        return this.tasksById.get(id);
    }

    public Task getByIndex(int index) {
        if (index < 0 || this.tasksById.size() <= index) {
            throw new IndexOutOfBoundsException();
        }
        return this.tasksById.values().stream().skip(index).findFirst().get();
    }

    public int cycle(int cycles) {
        if(this.getCount()  == 0){
            throw  new IllegalArgumentException();
        }

        SortedMap<Integer, SortedMap<Integer, Task>> newTasksByConsumptionRate = new TreeMap<>();
        int completedTasks = 0;

        for (Map.Entry<Integer, SortedMap<Integer, Task>> integerSortedMapEntry : tasksByConsumptionRate.entrySet()) {
            int consumption = integerSortedMapEntry.getKey();
            SortedMap<Integer, Task> submap = tasksByConsumptionRate.get(consumption);
            for (Task task : submap.values()) {
                task.setConsumption(consumption - cycles);
                if (consumption- cycles <= 0) {
                    this.tasksById.remove(task.getId());
                    this.tasksByPriority.get(task.getTaskPriority()).remove(task.getId());
                    completedTasks++;

                }
            }

            if (consumption-cycles > 0) {
                newTasksByConsumptionRate.putIfAbsent(consumption-cycles, new TreeMap<>());
                newTasksByConsumptionRate.put(consumption-cycles, submap);
            }
        }
        this.tasksByConsumptionRate = newTasksByConsumptionRate;
        return completedTasks;
    }

    public void changePriority(int id, Priority newPriority) {
        Task task = this.getById(id);
        this.tasksByPriority.get(task.getTaskPriority()).remove(task.getId());
        task.setTaskPriority(newPriority);
        this.tasksByPriority.get(newPriority).put(task.getId(), task);
    }

    public Iterable<Task> getByConsumptionRange(int lo, int hi, boolean inclusive) {
        if(!inclusive){
            lo += 1;
            hi -= 1;
        }
        List<Task> result =  new ArrayList<>();
        SortedMap<Integer, SortedMap<Integer, Task>> submap = this.tasksByConsumptionRate.subMap(lo, hi + 1);
        for (SortedMap<Integer, Task> priorityTaskSortedMap : submap.values()) {
            result.addAll(priorityTaskSortedMap.values());
        }
        return result.stream().sorted((x,y) -> y.getTaskPriority().compareTo(x.getTaskPriority()))
                .sorted(Comparator.comparing(Task::getConsumption)).collect(Collectors.toList())
                ;
    }

    public Iterable<Task> getByPriority(Priority priority) {
        return this.tasksByPriority.get(priority).values();
    }

    public Iterable<Task> getByPriorityAndMinimumConsumption(Priority priority, int lo) {
        return this.tasksByPriority.get(priority).values().stream().filter(t -> t.getConsumption() >= lo).collect(Collectors.toList());
    }

    public Iterator<Task> iterator() {
        return this.tasksById.values().iterator();
    }
}
