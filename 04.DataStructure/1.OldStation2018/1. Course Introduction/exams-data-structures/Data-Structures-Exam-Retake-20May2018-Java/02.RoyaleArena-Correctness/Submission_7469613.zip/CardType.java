
public enum CardType {

    MELEE,
    RANGED,
    SPELL,
    BUILDING

}
