
import java.util.*;
import java.util.stream.Collectors;

public class RoyaleArena implements Arena {

    private static final Comparator<Battlecard> COMPARATOR_BY_SWAG_ASC_THEN_ID = Comparator
            .comparing(Battlecard::getSwag)
            .thenComparing(Battlecard::getId);

    private static final Comparator<Battlecard> COMPARATOR_BY_SWAG_DESC_THEN_ID = Comparator
            .comparing(Battlecard::getSwag).reversed()
            .thenComparing(Battlecard::getId);

    private static final Comparator<Battlecard> COMPARATOR_BY_DAMAGE_DESC_THEN_ID = Comparator
            .comparing(Battlecard::getDamage).reversed()
            .thenComparing(Battlecard::getId);

    private Map<Integer, Battlecard> byId;

    public RoyaleArena() {
        this.byId = new LinkedHashMap<>();
    }

    public void add(Battlecard card) {
        this.byId.put(card.getId(), card);
    }

    public boolean contains(Battlecard card) {
        return this.byId.containsKey(card.getId());
    }

    public int getCount() {
        return this.byId.size();
    }

    public void changeCardType(int id, CardType type) {
        final Battlecard battlecard = this.byId.get(id);

        if (battlecard == null) {
            throw new IllegalArgumentException();
        }

        battlecard.setType(type);
    }

    public Battlecard getById(int id) {
        final Battlecard battlecard = this.byId.get(id);

        if (battlecard == null) {
            throw new IllegalArgumentException();
        }

        return battlecard;
    }

    public void removeById(int id) {
        if (this.byId.remove(id) == null) {
            throw new IllegalArgumentException();
        }
    }

    @Override
    public Iterable<Battlecard> getByCardType(final CardType type) {
        final List<Battlecard> cards = this.byId.values().stream()
                .filter(c -> c.getType() == type)
                .sorted(COMPARATOR_BY_DAMAGE_DESC_THEN_ID)
                .collect(Collectors.toList());

        if (cards.isEmpty()) {
            throw new IllegalArgumentException();
        }

        return cards;
    }

    @Override
    public Iterable<Battlecard> getByTypeAndDamageRangeOrderedByDamageThenById(final CardType type, final double lo, final double hi) {
        final List<Battlecard> cards = this.byId.values()
                .stream()
                .filter(c -> c.getType() == type && c.getDamage() > lo && c.getDamage() < hi)
                .sorted(COMPARATOR_BY_DAMAGE_DESC_THEN_ID)
                .collect(Collectors.toList());

        if (cards.isEmpty()) {
            throw new IllegalArgumentException();
        }

        return cards;
    }

    @Override
    public Iterable<Battlecard> getByCardTypeAndMaximumDamage(final CardType type, final double damage) {
        final List<Battlecard> cards = this.byId.values()
                .stream()
                .filter(c -> c.getType() == type && c.getDamage() <= damage)
                .sorted(COMPARATOR_BY_DAMAGE_DESC_THEN_ID)
                .collect(Collectors.toList());

        if (cards.isEmpty()) {
            throw new IllegalArgumentException();
        }

        return cards;
    }

    @Override
    public Iterable<Battlecard> getByNameOrderedBySwagDescending(final String name) {
        final List<Battlecard> cards = this.byId.values()
                .stream()
                .filter(c -> c.getName().equals(name))
                .sorted(COMPARATOR_BY_SWAG_DESC_THEN_ID)
                .collect(Collectors.toList());

        if (cards.isEmpty()) {
            throw new IllegalArgumentException();
        }

        return cards;
    }

    @Override
    public Iterable<Battlecard> getByNameAndSwagRange(final String name, final double lo, final double hi) {
        final List<Battlecard> cards = this.byId.values()
                .stream()
                .filter(c ->
                        c.getName().equals(name) &&
                                c.getSwag() >= lo &&
                                c.getSwag() < hi)
                .sorted(COMPARATOR_BY_SWAG_DESC_THEN_ID)
                .collect(Collectors.toList());

        if (cards.isEmpty()) {
            throw new IllegalArgumentException();
        }

        return cards;
    }

    @Override
    public Iterable<Battlecard> getAllByNameAndSwag() {
        // TODO - ORDER???
        Map<String, Battlecard> cards = new LinkedHashMap<>();
        this.byId.values().forEach(c -> {
            cards.putIfAbsent(c.getName(), c);
            if (cards.get(c.getName()).getSwag() < c.getSwag()) {
                cards.replace(c.getName(), c);
            }
        });

        if (cards.isEmpty()) {
            throw new IllegalArgumentException();
        }

        return cards.values();
    }

    @Override
    public Iterable<Battlecard> findFirstLeastSwag(final int n) {
        if (this.byId.size() < n) {
            throw new IllegalArgumentException();
        }

        return this.byId.values()
                .stream()
                .sorted(COMPARATOR_BY_SWAG_ASC_THEN_ID)
                .limit(n)
                .collect(Collectors.toList());
    }

    @Override
    public Iterable<Battlecard> getAllInSwagRange(final double lo, final double hi) {
        return this.byId.values()
                .stream()
                .filter(c -> c.getSwag() >= lo && c.getSwag() <= hi)
                .sorted(COMPARATOR_BY_SWAG_ASC_THEN_ID)
                .collect(Collectors.toList());
    }


    @Override
    public Iterator<Battlecard> iterator() {
        return this.byId.values().iterator();
    }
}
