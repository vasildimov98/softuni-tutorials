

import java.util.*;
import java.util.stream.Collectors;

public class Instock implements ProductStock {

    private SortedMap<String, Product> productByLabel;
    private SortedMap<Double, List<String>> productByPrice;
    private SortedMap<Integer, List<String>> productByQuantity;
    private List<String> productByIndex;

    public Instock() {
        this.productByLabel = new TreeMap<>();
        this.productByPrice = new TreeMap<>(Comparator.reverseOrder());
        this.productByQuantity = new TreeMap<>();
        this.productByIndex = new ArrayList<>();
    }

    @Override
    public int getCount() {
        return this.productByIndex.size();
    }

    @Override
    public boolean contains(Product product) {
        Product p = this.productByLabel.get(product.getLabel());
        if (p == null) {
            return false;
        }
        return true;
    }

    @Override
    public void add(Product product) {
        this.productByLabel.putIfAbsent(product.getLabel(), product);
        this.productByPrice.putIfAbsent(product.getPrice(), new ArrayList<>());
        this.productByPrice.get(product.getPrice()).add(product.getLabel());
        this.productByQuantity.putIfAbsent(product.getQuantity(), new ArrayList<>());
        this.productByQuantity.get(product.getQuantity()).add(product.getLabel());
        this.productByIndex.add(product.getLabel());
    }

    @Override
    public void changeQuantity(String label, int quantity) {
        if (productByLabel.containsKey(label)) {
            Product p =  productByLabel.get(label);
            productByQuantity.get(p.getQuantity()).remove(label);
            productByLabel.get(label).setQuantity(quantity);
            this.productByQuantity.putIfAbsent(quantity, new ArrayList<>());
            this.productByQuantity.get(quantity).add(label);
        } else {
            throw new IllegalArgumentException();
        }
    }

    @Override
    public Product find(int index) {
        Product p = productByLabel.get(productByIndex.get(index));
        if (p == null) {
            throw new IndexOutOfBoundsException();
        }
        return p;
    }

    @Override
    public Product findByLabel(String label) {
        Product p = productByLabel.get(label);
        if (p == null) {
            throw new IllegalArgumentException();
        }
        return p;
    }

    @Override
    public Iterable<Product> findFirstByAlphabeticalOrder(int count) {
        if (count < 0 || count > this.getCount()) {
            throw new IllegalArgumentException();
        }
        List<Product> firstNProducts = new ArrayList<>();
        Iterator<Product> productIterator = this.productByLabel.values().iterator();
        for (int i = 0; i < count; i++) {
            firstNProducts.add(productIterator.next());
        }
        return firstNProducts;
    }

    @Override
    public Iterable<Product> findAllInRange(double lo, double hi) {
        List<Product> productsInPriceRange = new ArrayList<>();
        Map<Double, List<String>> subMap = productByPrice.subMap(hi, lo);
        for (List<String> products : subMap.values()) {
            productsInPriceRange.addAll(products.stream().map(p -> productByLabel.get(p)).collect(Collectors.toList()));
        }
        return productsInPriceRange;
    }

    @Override
    public Iterable<Product> findAllByPrice(double price) {
        List<Product> products = new ArrayList<>();
        List<String> productsStrings = productByPrice.get(price);
        if (productsStrings != null) {
            products = productsStrings.stream().map(p -> productByLabel.get(p)).collect(Collectors.toList());
        }
        return products;
    }

    @Override
    public Iterable<Product> findFirstMostExpensiveProducts(int count) {
        List<Product> mostExpensiveProducts = new ArrayList<>();
        Iterator<List<String>> iterator = this.productByPrice.values().iterator();
        for (int i = 0; i < count && iterator.hasNext(); ) {
            List<String> productsList = iterator.next();
            for (String s : productsList) {
                if (i < count) {
                    mostExpensiveProducts.add(productByLabel.get(s));
                    i++;
                } else {
                    break;
                }
            }
        }
        if (mostExpensiveProducts.size() < count) {
            throw new IllegalArgumentException();
        }
        return mostExpensiveProducts;
    }

    @Override
    public Iterable<Product> findAllByQuantity(int quantity) {
        List<Product> products = new ArrayList<>();
        List<String> productsStrings = productByQuantity.get(quantity);
        if (productsStrings != null) {
            products = productsStrings.stream().map(p -> productByLabel.get(p)).collect(Collectors.toList());
        }
        return products;
    }

    @Override
    public Iterator<Product> iterator() {
        return this.productByIndex.stream().map(p-> productByLabel.get(p)).iterator();
    }
}
