
public class Task implements Comparable<Task> {

    private int id;
    private int consumption;
    private Priority taskPriority;


    public Task(int id, int consumption, Priority priority){

        this.id = id;
        this.consumption = consumption;
        this.taskPriority = priority;

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getConsumption() {
        return consumption;
    }

    public void setConsumption(int consumption) {
        this.consumption = consumption;
    }

    public Priority getTaskPriority() {
        return taskPriority;
    }

    public void setTaskPriority(Priority taskPriority) {
        this.taskPriority = taskPriority;
    }

    public int compareTo(Task o) {
        return Integer.compare(this.getId(), o.getId());
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Task{");
        sb.append("id=").append(id);
        sb.append(", consumption=").append(consumption);
        sb.append(", taskPriority=").append(taskPriority);
        sb.append('}');
        return sb.toString();
    }
}
