

import java.util.*;
import java.util.stream.Collectors;

public class ThreadExecutor implements Scheduler {

    private List<Task> byIndex;
    private Map<Integer, Task> byId;
    private Map<Priority, Set<Task>> byPriority;

    public ThreadExecutor() {
        this.byIndex = new ArrayList<>();
        this.byId = new HashMap<>();
        this.byPriority = new HashMap<Priority, Set<Task>>() {{
            put(Priority.LOW, new TreeSet<>(Comparator.comparingInt(Task::getId).reversed()));
            put(Priority.MEDIUM, new TreeSet<>(Comparator.comparingInt(Task::getId).reversed()));
            put(Priority.HIGH, new TreeSet<>(Comparator.comparingInt(Task::getId).reversed()));
            put(Priority.EXTREME, new TreeSet<>(Comparator.comparingInt(Task::getId).reversed()));
        }};
    }

    @Override
    public int getCount() {
        return this.byId.size();
    }

    @Override
    public void execute(Task t) {
        if (this.byId.containsKey(t.getId())) {
            throw new IllegalArgumentException();
        }

        this.byId.put(t.getId(), t);
        this.byIndex.add(t);
        this.byPriority.get(t.getTaskPriority()).add(t);
    }

    @Override
    public boolean contains(Task t) {
        return this.byId.containsKey(t.getId());
    }

    @Override
    public Task getById(int id) {
        Task task = this.byId.get(id);

        if (task == null) {
            throw new IllegalArgumentException();
        }

        return task;
    }

    @Override
    public Task getByIndex(int index) {
        return this.byIndex.get(index);
    }

    @Override
    public int cycle(int cycles) {
        if (this.byIndex.size() == 0) {
            throw new IllegalArgumentException();
        }

        List<Task> byIndex = new ArrayList<>(this.byIndex.size()/2);
        int removed = 0;
        for (Task task : this.byIndex) {
            if (task.getConsumption() <= cycles) {
                this.byId.remove(task.getId());
                this.byPriority.get(task.getTaskPriority()).remove(task);
                removed++;
                continue;
            }

            task.setConsumption(task.getConsumption() - cycles);
            byIndex.add(task);
        }
        this.byIndex = byIndex;
        return removed;
    }

    @Override
    public void changePriority(int index, Priority newPriority) {
        final Task task = this.byId.get(index);
        if (task == null) {
            throw new IllegalArgumentException();
        }

        this.byPriority.get(task.getTaskPriority()).remove(task);
        task.setTaskPriority(newPriority);
        this.byPriority.get(newPriority).add(task);
    }

    @Override
    public Iterable<Task> getByConsumptionRange(int lo, int hi, boolean inclusive) {
        List<Task> result = new ArrayList<>(this.byIndex.size());
/*        Set<Task> result = new TreeSet<>((t1, t2) -> {
            int cmp = t1.getConsumption() - t2.getConsumption();
            if (cmp == 0) {
                cmp = t2.getTaskPriority().ordinal() - t1.getTaskPriority().ordinal();
            }
            if (cmp == 0) {
                cmp = t1.getId() - t2.getId();
            }
            return cmp;
        });*/
        for (Task task : this.byIndex) {
            int consumption = task.getConsumption();
            if (consumption > lo && consumption < hi || inclusive && (consumption == lo || consumption == hi)) {
                 result.add(task);
            }
        }
        result.sort((t1, t2) -> {
            int cmp = t1.getConsumption() - t2.getConsumption();
            if (cmp == 0) {
                cmp = t2.getTaskPriority().ordinal() - t1.getTaskPriority().ordinal();
            }
            return cmp;
        });

        return result;
    }

    @Override
    public Iterable<Task> getByPriority(Priority priority) {
        return this.byPriority.get(priority);
    }

    @Override
    public Iterable<Task> getByPriorityAndMinimumConsumption(Priority priority, int lo) {
        return this.byPriority
                .get(priority)
                .stream()
                .filter(task -> task.getConsumption() >= lo)
                .collect(Collectors.toList());
    }

    @Override
    public Iterator<Task> iterator() {
        return this.byIndex.iterator();
    }
}
