import com.sun.org.apache.xpath.internal.operations.Or;
import sun.awt.image.ImageWatched;

import java.util.*;

public class Organization implements IOrganization {

    private class OrganizationIterator<Person> implements Iterator<Person> {

        private LinkedList<Person> collection;

        public OrganizationIterator(LinkedList<Person> collection) {
            this.collection = collection;
        }

        @Override
        public boolean hasNext() {
            return collection.size() > 0;
        }

        @Override
        public Person next() {
            return this.collection.removeFirst();
        }
    }

    private Map<String, LinkedHashSet<Person>> personsByName;

    private List<Person> indexedPersons;

    private int count;

    public Organization() {
        this.personsByName = new LinkedHashMap<String, LinkedHashSet<Person>>();
        this.indexedPersons = new ArrayList<Person>();
        this.count = 0;
    }

    @Override
    public int getCount() {
        return this.count;
    }

    @Override
    public boolean contains(Person person) {
        if(this.personsByName.containsKey(person.getName())) {
            return this.personsByName.get(person.getName()).contains(person);
        }

        return false;
    }

    @Override
    public boolean containsByName(String name) {
        return this.personsByName.containsKey(name);
    }

    @Override
    public void add(Person person) {
        if(!this.personsByName.containsKey(person.getName())) {
            this.personsByName.put(person.getName(), new LinkedHashSet<Person>());
        }

        this.personsByName.get(person.getName()).add(person);
        this.indexedPersons.add(person);
        this.count++;
    }

    @Override
    public Person getAtIndex(int index) {
        if(index < 0 || index >= this.indexedPersons.size()) {
            throw new IllegalArgumentException();
        }

        return this.indexedPersons.get(index);
    }

    @Override
    public Iterable<Person> getByName(String name) {
        if(!this.personsByName.containsKey(name)) {
            return new ArrayList<Person>();
        }

        return this.personsByName.get(name);
    }

    @Override
    public Iterable<Person> firstByInsertOrder() {
        List<Person> resultPersons = new ArrayList<Person>();

        if(this.count == 0) {
            return resultPersons;
        }

        resultPersons.add(this.indexedPersons.get(0));

        return resultPersons;
    }

    @Override
    public Iterable<Person> firstByInsertOrder(int count) {
        List<Person> resultPersons = new ArrayList<Person>();

        if(this.count == 0) {
            return resultPersons;
        }

        for (int i = 0; i < count && i < this.indexedPersons.size(); i++) {
            resultPersons.add(this.indexedPersons.get(i));
        }

        return resultPersons;
    }

    @Override
    public Iterable<Person> searchWithNameSize(int minLength, int maxLength) {
        List<Person> resultPersons = new ArrayList<Person>();

        for (Map.Entry<String,LinkedHashSet<Person>> personEntry : this.personsByName.entrySet()) {
            if(personEntry.getKey().length() >= minLength && personEntry.getKey().length() <= maxLength) {
                resultPersons.addAll(personEntry.getValue());
            }
        }

        return resultPersons;
    }

    @Override
    public Iterable<Person> getWithNameSize(int length) {
        List<Person> resultPersons = new ArrayList<Person>();

        for (Map.Entry<String,LinkedHashSet<Person>> personEntry : this.personsByName.entrySet()) {
            if(personEntry.getKey().length() == length) {
                resultPersons.addAll(personEntry.getValue());
            }
        }

        if(resultPersons.size() == 0) {
            throw new IllegalArgumentException();
        }

        return resultPersons;
    }

    @Override
    public Iterable<Person> peopleByInsertOrder() {
        return this.indexedPersons;
    }

    @Override
    public Iterator<Person> iterator() {
        LinkedList<Person> persons = new LinkedList<Person>();

        for (Person indexedPerson : this.indexedPersons) {
            persons.addLast(indexedPerson);
        }

        return new OrganizationIterator<Person>(persons);
    }
}
