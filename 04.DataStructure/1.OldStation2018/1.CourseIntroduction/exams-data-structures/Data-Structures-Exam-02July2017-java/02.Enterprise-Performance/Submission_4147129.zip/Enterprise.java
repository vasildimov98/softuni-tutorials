import java.time.LocalDate;
import java.time.Month;
import java.util.*;

public class Enterprise implements IEnterprise {

    private class EnterpriseIterator<Employee> implements Iterator<Employee> {

        private LinkedList<Employee> collection;

        private EnterpriseIterator(LinkedList<Employee> collection) {
            this.collection = collection;
        }

        @Override
        public boolean hasNext() {
            return this.collection.size() > 0;
        }

        @Override
        public Employee next() {
            return this.collection.removeFirst();
        }
    }

    private Map<UUID, Employee> employeesById;

    private int count;

    public Enterprise() {
        this.employeesById = new LinkedHashMap<UUID, Employee>();
        this.count = 0;
    }

    @Override
    public void add(Employee employee) {
        this.employeesById.put(employee.getId(), employee);
        this.count++;
    }

    @Override
    public boolean contains(UUID id) {
        return this.employeesById.containsKey(id);
    }

    @Override
    public boolean contains(Employee employee) {
        return this.employeesById.containsKey(employee.getId());
    }

    @Override
    public boolean change(UUID id, Employee employee) {
        if(this.contains(id)) {
            this.employeesById.replace(id, employee);
            return true;
        }

        return false;
    }

    @Override
    public boolean fire(UUID id) {
        if(this.employeesById.containsKey(id)) {
            this.employeesById.remove(id);
            this.count--;
            return true;
        }

        return false;
    }

    @Override
    public boolean raiseSalary(int months, int percent) {
        Calendar startCalendar = new GregorianCalendar();
        startCalendar.setTime(new Date());

        boolean hasModified = false;

        for (Map.Entry<UUID, Employee> employeeEntry : employeesById.entrySet()) {
            Calendar endCalendar = new GregorianCalendar();
            endCalendar.setTime(employeeEntry.getValue().getHireDate());

            int diffYear = endCalendar.get(Calendar.YEAR) - startCalendar.get(Calendar.YEAR);
            int diffMonth = diffYear * 12 + endCalendar.get(Calendar.MONTH) - startCalendar.get(Calendar.MONTH);

            if(months >= diffMonth) {
                employeeEntry.getValue().setSalary(employeeEntry.getValue().getSalary() + (employeeEntry.getValue().getSalary() * percent) / 100);
                hasModified = true;
            }
        }
        
        return hasModified;
    }

    @Override
    public int getCount() {
        return this.count;
    }

    @Override
    public Employee getByUUID(UUID id) {
        if(!this.employeesById.containsKey(id)) {
            throw new IllegalArgumentException();
        }

        return this.employeesById.get(id);
    }

    @Override
    public Position positionByUUID(UUID id) {
        if(!this.employeesById.containsKey(id)) {
            throw new IllegalArgumentException();
        }

        return this.employeesById.get(id).getPosition();
    }

    @Override
    public Iterable<Employee> getByPosition(Position position) {
        LinkedList<Employee> employees = new LinkedList<Employee>();

        for (Map.Entry<UUID, Employee> employeeEntry : employeesById.entrySet()) {
            if(employeeEntry.getValue().getPosition().equals(position)) {
                employees.addLast(employeeEntry.getValue());
            }
        }

        if(employees.size() == 0) {
            throw new IllegalArgumentException();
        }

        return employees;
    }

    @Override
    public Iterable<Employee> getBySalary(double minSalary) {
        LinkedList<Employee> employees = new LinkedList<Employee>();

        for (Map.Entry<UUID, Employee> employeeEntry : employeesById.entrySet()) {
            if(employeeEntry.getValue().getSalary() >= minSalary) {
                employees.addLast(employeeEntry.getValue());
            }
        }

        if(employees.size() == 0) {
            throw new IllegalArgumentException();
        }

        return employees;
    }

    @Override
    public Iterable<Employee> getBySalaryAndPosition(double salary, Position position) {
        LinkedList<Employee> employees = new LinkedList<Employee>();

        for (Map.Entry<UUID, Employee> employeeEntry : employeesById.entrySet()) {
            if(employeeEntry.getValue().getPosition().equals(position) && employeeEntry.getValue().getSalary() == salary) {
                employees.addLast(employeeEntry.getValue());
            }
        }

        if(employees.size() == 0) {
            throw new IllegalArgumentException();
        }

        return employees;
    }

    @Override
    public Iterable<Employee> searchBySalary(double minSalary, double maxSalary) {
        LinkedList<Employee> employees = new LinkedList<Employee>();

        for (Map.Entry<UUID, Employee> employeeEntry : employeesById.entrySet()) {
            if(employeeEntry.getValue().getSalary() >= minSalary && employeeEntry.getValue().getSalary() <= maxSalary) {
                employees.addLast(employeeEntry.getValue());
            }
        }

        return employees;
    }

    @Override
    public Iterable<Employee> searchByPosition(Iterable<Position> positions) {
        HashSet<Position> searchPositions = new HashSet<Position>();

        for (Position position : positions) {
            searchPositions.add(position);
        }

        LinkedList<Employee> employees = new LinkedList<Employee>();

        for (Map.Entry<UUID, Employee> employeeEntry : employeesById.entrySet()) {
            if(searchPositions.contains(employeeEntry.getValue().getPosition())) {
                employees.addLast(employeeEntry.getValue());
            }
        }

        return employees;
    }

    @Override
    public Iterable<Employee> allWithPositionAndMinSalary(Position position, double minSalary) {
        LinkedList<Employee> employees = new LinkedList<Employee>();

        for (Map.Entry<UUID, Employee> employeeEntry : employeesById.entrySet()) {
            if(employeeEntry.getValue().getPosition().equals(position) && employeeEntry.getValue().getSalary() <= minSalary) {
                employees.addLast(employeeEntry.getValue());
            }
        }

        return employees;
    }

    @Override
    public Iterable<Employee> searchByFirstName(String firstName) {
        LinkedList<Employee> employees = new LinkedList<Employee>();

        for (Map.Entry<UUID, Employee> employeeEntry : employeesById.entrySet()) {
            if(employeeEntry.getValue().getFirstName().equals(firstName)) {
                employees.addLast(employeeEntry.getValue());
            }
        }

        return employees;
    }

    @Override
    public Iterable<Employee> searchByNameAndPosition(String firstName, String lastName, Position position) {
        LinkedList<Employee> employees = new LinkedList<Employee>();

        for (Map.Entry<UUID, Employee> employeeEntry : employeesById.entrySet()) {
            if(employeeEntry.getValue().getFirstName().equals(firstName) && employeeEntry.getValue().getLastName().equals(lastName) && employeeEntry.getValue().getPosition().equals(position)) {
                employees.addLast(employeeEntry.getValue());
            }
        }

        return employees;
    }

    @Override
    public Iterator<Employee> iterator() {
        LinkedList<Employee> collection = new LinkedList<Employee>();

        for (Employee employee : this.employeesById.values()) {
            collection.addLast(employee);
        }

        return new EnterpriseIterator<Employee>(collection);
    }
}
