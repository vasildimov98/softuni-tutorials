﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static Dictionary<int, Tree<int>> tree = new Dictionary<int, Tree<int>>();
    static void Main()
    {
        int n = int.Parse(Console.ReadLine());

        ReadTree(n);
        Tree<int> root = GetRootNode();

        //01. Root Node
        //Console.WriteLine($"Root node: {root.Value}");

        //02. Print Tree;
        //PrintTree(root);

        //03. Leaf Nodes
        //List<Tree<int>> leafs = GetAllLeafNodesIncreacingOrder();
        //string leafTxt = "Leaf nodes: ";
        //PrintNodes(leafTxt, leafs);

        //04. Middle Nodes
        List<Tree<int>> middleNodes = GetAllMiddleNodesIncreacingOrder();
        string middleTxt = "Middle nodes: ";
        PrintNodes(middleTxt, middleNodes);

    }

    private static List<Tree<int>> GetAllMiddleNodesIncreacingOrder()
    {
        return tree
           .Values
           .Where(l => l.Children.Count > 0 && l.Parent != null)
           .OrderBy(l => l.Value)
           .ToList();
    }

    private static void PrintNodes(string text, List<Tree<int>> nodes)
    {
        StringBuilder sb = new StringBuilder();
        foreach (var node in nodes)
        {
            sb.Append(node.Value + " ");
        }
        Console.WriteLine($"{text}{sb.ToString().TrimEnd()}");
    }

    private static List<Tree<int>> GetAllLeafNodesIncreacingOrder()
    {
        return tree
            .Values
            .Where(l => l.Children.Count == 0)
            .OrderBy(l => l.Value)
            .ToList();
    }

    private static void PrintTree(Tree<int> node, int indent = 0)
    {
        Console.WriteLine($"{new string(' ', indent)}{node.Value}");
        foreach (var child in node.Children)
        {
            PrintTree(child, indent + 2);
        }
    }

    private static Tree<int> GetRootNode()
    {
        return tree
            .Values
            .FirstOrDefault(x => x.Parent == null);
    }

    private static void ReadTree(int n)
    {
        for (int i = 0; i < n - 1; i++)
        {
            int[] input = Console
                .ReadLine()
                .Split()
                .Select(int.Parse)
                .ToArray();

            int parent = input[0];
            int child = input[1];

            if (!tree.ContainsKey(parent))
            {
                tree.Add(parent, new Tree<int>(parent));
            }

            if (!tree.ContainsKey(child))
            {
                tree.Add(child, new Tree<int>(child));
            }

            Tree<int> parentNode = tree[parent];
            Tree<int> childNode = tree[child];

            parentNode.Children.Add(childNode);
            childNode.Parent = parentNode;
        }
    }
}

public class Tree<T>
{
    public Tree(T value, params Tree<T>[] children)
    {
        Value = value;
        this.Children = new List<Tree<T>>();
        foreach (Tree<T> child in children)
        {
            this.Children.Add(child);
            child.Parent = this;
        }
    }

    public T Value { get; set; }
    public Tree<T> Parent { get; set; }
    public List<Tree<T>> Children { get; set; }
}


