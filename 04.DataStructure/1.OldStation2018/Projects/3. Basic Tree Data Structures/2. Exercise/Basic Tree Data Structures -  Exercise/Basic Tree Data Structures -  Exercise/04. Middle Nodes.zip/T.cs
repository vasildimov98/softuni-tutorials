﻿internal class T
{
}