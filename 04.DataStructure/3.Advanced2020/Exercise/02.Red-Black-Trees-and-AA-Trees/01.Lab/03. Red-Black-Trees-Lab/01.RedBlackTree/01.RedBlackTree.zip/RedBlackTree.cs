﻿namespace _01.RedBlackTree
{
    using System;
    using System.Collections.Generic;

    public class RedBlackTree<T>
        : IBinarySearchTree<T> where T : IComparable
    {
        private readonly bool Red = true;
        private readonly bool Black = false;

        private class Node
        {
            public Node(T value)
            {
                this.Value = value;
                this.Color = true;
            }

            public T Value { get; set; }

            public Node Left { get; set; }
            public Node Right { get; set; }

            public int Count { get; set; }

            public bool Color { get; set; }
        }

        private Node root;

        public RedBlackTree() { }

        private RedBlackTree(Node foundElement)
        {
            this.PreOrderCopy(foundElement);
        }

        public void Insert(T element)
        {
            this.root = this.InsertNewNode(this.root, element);
            this.root.Color = this.Black;
        }

        public void Delete(T element)
        {
            this.ValidateTreeNotEmpty();

            this.root = this.DeleteNode(this.root, element);
        }

        public void DeleteMax()
        {
            this.ValidateTreeNotEmpty();

            this.root = this.DeleteMaxNode(this.root);
        }

        public void DeleteMin()
        {
            this.ValidateTreeNotEmpty();

            this.root = this.DeleteMinNode(this.root);
        }

        public bool Contains(T element)
        {
            return this.FindElement(element) != null;
        }

        public IBinarySearchTree<T> Search(T element)
        {
            var foundElement = this.FindElement(element);

            return new RedBlackTree<T>(foundElement);
        }

        public T Ceiling(T value)
        {
            return this.Select(this.Rank(value) + 1);
        }

        public T Floor(T value)
        {
            return this.Select(this.Rank(value) - 1);
        }

        public void EachInOrder(Action<T> action)
        {
            this.EachInOrder(this.root, action);
        }

        public IEnumerable<T> Range(T startRange, T endRange)
        {
            var elementsInRange = new Queue<T>();

            this.SelectElementsInRange(this.root, elementsInRange, startRange, endRange);

            return elementsInRange;
        }

        public int Count()
        {
            return this.GetSubtreeCount(this.root);
        }

        public int Rank(T value)
        {
            return this.GetValueRank(this.root, value);
        }

        public T Select(int rank)
        {
            var selectedNode = this.SelectNodeByRank(this.root, rank);
            if (selectedNode == null)
                throw new InvalidOperationException("Tree does't contain such node");

            return selectedNode.Value;
        }

        private void SelectElementsInRange(Node current, Queue<T> queue, T startRange, T endRange)
        {
            if (current == null)
                return;

            if (this.CurrentNodeIsInLowerRange(startRange, current.Value))
                this.SelectElementsInRange(current.Left, queue, startRange, endRange);
            if (this.CurrentNodeIsInRange(current.Value, startRange, endRange))
                queue.Enqueue(current.Value);
            if (this.CurrentNodeIsHigherRange(endRange, current.Value))
                this.SelectElementsInRange(current.Right, queue, startRange, endRange);
        }

        private bool CurrentNodeIsInRange(T nodeValue, T startRange, T endRange)
        {
            return (this.IsGreater(nodeValue, startRange)
                || this.IsEqual(nodeValue, startRange))
                && (this.IsLess(nodeValue, endRange)
                || this.IsEqual(nodeValue, endRange));
        }

        private bool CurrentNodeIsHigherRange(T higherRange, T nodeValue)
        {
            return this.IsGreater(higherRange, nodeValue);
        }

        private bool CurrentNodeIsInLowerRange(T lowerRange, T nodeValue)
        {
            return this.IsLess(lowerRange, nodeValue);
        }

        private Node SelectNodeByRank(Node node, int rank)
        {
            if (node == null)
                return null;

            var leftSubtreeCount = this.GetSubtreeCount(node.Left);
            if (leftSubtreeCount == rank)
                return node;

            if (leftSubtreeCount > rank)
                return this.SelectNodeByRank(node.Left, rank);


            return this.SelectNodeByRank(node.Right, rank - (leftSubtreeCount + 1));
        }

        private Node InsertNewNode(Node node, T element)
        {
            // the node position was located
            if (node == null)
                // 2. Create a new red node
                node = new Node(element);
            // 1. Locate the node position
            else if (this.IsLess(element, node.Value))
                // 3. Add new Node to the tree left side
                node.Left = this.InsertNewNode(node.Left, element);
            else if (this.IsGreater(element, node.Value))
                // 3. Add new Node to the tree right side
                node.Right = this.InsertNewNode(node.Right, element);

            // 4. Balance subtree if needed
            node = this.BalanceSubtreeIfNeeded(node);

            node.Count = 1
                + this.GetSubtreeCount(node.Left)
                + this.GetSubtreeCount(node.Right);
            return node;
        }

        private Node BalanceSubtreeIfNeeded(Node node)
        {
            if (this.IsRed(node.Right)
                && !this.IsRed(node.Left))
                node = this.RotateLeft(node);

            if (this.IsRed(node.Left)
                && this.IsRed(node.Left.Left))
                node = this.RotateRight(node);

            if (this.IsRed(node.Left)
                && this.IsRed(node.Right))
                this.FlipColors(node);
            return node;
        }

        private void FlipColors(Node node)
        {
            node.Color = this.Red;
            node.Left.Color = this.Black;
            node.Right.Color = this.Black;
        }

        private Node RotateRight(Node node)
        {
            var leftChild = node.Left;
            node.Left = leftChild.Right;
            leftChild.Right = node;

            leftChild.Color = node.Color;
            node.Color = this.Red;

            node.Count = 1 + this.GetSubtreeCount(node.Left)
                + this.GetSubtreeCount(node.Right);

            return leftChild;
        }

        private Node RotateLeft(Node node)
        {
            var rightChild = node.Right;
            node.Right = rightChild.Left;
            rightChild.Left = node;

            rightChild.Color = node.Color;
            node.Color = this.Red;


            node.Count = 1 + this.GetSubtreeCount(node.Left)
                + this.GetSubtreeCount(node.Right);

            return rightChild;
        }

        private bool IsRed(Node node)
        {
            return node != null
                && node.Color == this.Red;
        }

        private Node DeleteNode(Node node, T element)
        {
            if (node == null)
                return null;

            if (this.IsLess(element, node.Value))
                node.Left = this.DeleteNode(node.Left, element);
            else if (this.IsGreater(element, node.Value))
                node.Right = this.DeleteNode(node.Right, element);
            else
            {
                if (this.IsLeaf(node))
                    return null;
                else if (this.HasOnlyLeftSubtree(node))
                    return node.Left;
                else if (this.HasOnlyRightSubtree(node))
                    return node.Right;
                else
                {
                    var tempNode = node;
                    var maxElementFromLeftSide = this.FindMaxElement(node.Left);
                    node = maxElementFromLeftSide;
                    node.Left = this.DeleteMaxNode(tempNode.Left);
                    node.Right = tempNode.Right;
                }
            }

            node.Count = 1 + this.GetSubtreeCount(node.Left) + this.GetSubtreeCount(node.Right);
            return node;
        }

        private Node DeleteMaxNode(Node node)
        {
            if (node.Right == null)
                return node.Left;
            else node.Right = this.DeleteMaxNode(node.Right);

            node.Count = 1 + this.GetSubtreeCount(node.Left) +
                this.GetSubtreeCount(node.Right);

            return node;
        }

        private Node DeleteMinNode(Node node)
        {
            if (node.Left == null)
                return node.Right;
            else node.Left = this.DeleteMinNode(node.Left);

            node.Count = 1 + this.GetSubtreeCount(node.Left) + this.GetSubtreeCount(node.Right);
            return node;
        }

        private void EachInOrder(Node node, Action<T> action)
        {
            if (node == null)
                return;

            this.EachInOrder(node.Left, action);
            action.Invoke(node.Value);
            this.EachInOrder(node.Right, action);
        }

        private void PreOrderCopy(Node node)
        {
            if (node == null)
                return;

            this.Insert(node.Value);
            this.PreOrderCopy(node.Left);
            this.PreOrderCopy(node.Right);
        }

        private Node FindElement(T element)
        {
            var currentNode = this.root;

            while (currentNode != null)
            {
                if (this.IsLess(element, currentNode.Value))
                    currentNode = currentNode.Left;
                else if (this.IsGreater(element, currentNode.Value))
                    currentNode = currentNode.Right;
                else break;
            }

            return currentNode;
        }

        private Node FindMaxElement(Node node)
        {
            if (node.Right == null)
                return node;

            return this.FindMaxElement(node.Right);
        }

        private bool HasOnlyRightSubtree(Node node)
        {
            return node.Left == null
           && node.Right != null;
        }

        private bool HasOnlyLeftSubtree(Node node)
        {
            return node.Left != null
           && node.Right == null;
        }

        private bool IsLeaf(Node node)
        {
            return node.Left == null
            && node.Right == null;
        }

        private int GetValueRank(Node subtree, T value)
        {
            if (subtree == null)
                return 0;

            if (this.IsLess(value, subtree.Value))
                return this.GetValueRank(subtree.Left, value);
            else if (this.IsGreater(value, subtree.Value))
                return 1
                    + this.GetSubtreeCount(subtree.Left)
                    + this.GetValueRank(subtree.Right, value);
            else return this.GetSubtreeCount(subtree.Left);
        }

        private int GetSubtreeCount(Node subtree)
        {
            if (subtree == null)
                return 0;

            return subtree.Count;
        }

        private bool IsEqual(T firstValue, T secondValue)
        {
            return firstValue.CompareTo(secondValue) == 0;
        }

        private bool IsGreater(T firstValue, T secondValue)
        {
            return firstValue.CompareTo(secondValue) > 0;
        }

        private bool IsLess(T firstValue, T secondValue)
        {
            return firstValue.CompareTo(secondValue) < 0;
        }

        private void ValidateTreeNotEmpty()
        {
            if (this.root == null)
                throw new InvalidOperationException("Tree is empty!!!");
        }
    }
}