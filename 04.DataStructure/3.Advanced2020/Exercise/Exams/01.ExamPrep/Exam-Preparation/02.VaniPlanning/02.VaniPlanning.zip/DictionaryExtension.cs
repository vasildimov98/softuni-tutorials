﻿using System.Collections.Generic;

namespace _02.VaniPlanning
{
    public static class DictionaryExtension
    {
        public static void AddValueToKey<TKey, IColleciton, TValue>(this IDictionary<TKey, IColleciton> dict,
            TKey key,
            TValue value)
            where IColleciton : ICollection<TValue>, new()
        {
            if (!dict.ContainsKey(key))
                dict[key] = new IColleciton();

            dict[key].Add(value);
        }
    }
}
