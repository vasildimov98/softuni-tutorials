﻿namespace MilitaryElite.IO
{
    public interface IReadable
    {
        string ReadLine();
    }
}
