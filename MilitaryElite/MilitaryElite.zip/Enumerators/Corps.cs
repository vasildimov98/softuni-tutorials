﻿namespace MilitaryElite.Enumerators
{
    public enum Corps
    {
        Airforces = 1,
        Marines = 2
    }
}
