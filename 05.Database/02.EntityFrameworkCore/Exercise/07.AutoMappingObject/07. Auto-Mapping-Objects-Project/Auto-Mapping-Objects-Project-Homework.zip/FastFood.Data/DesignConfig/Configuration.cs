﻿namespace FastFood.Data.DesignConfig
{
    public static class Configuration
    {
        public const string ConnetionString =             "Server=.;Database=FastFood;Trusted_Connection=True;MultipleActiveResultSets=true";
    }
}
