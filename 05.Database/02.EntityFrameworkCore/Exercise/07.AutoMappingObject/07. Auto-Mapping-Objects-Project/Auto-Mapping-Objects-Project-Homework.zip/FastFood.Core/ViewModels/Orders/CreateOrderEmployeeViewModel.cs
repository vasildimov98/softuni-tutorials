﻿namespace FastFood.Core.ViewModels.Orders
{
    public class CreateOrderEmployeeViewModel
    {
        public int Id { get; set; }

        public string PositionName { get; set; }
    }
}
