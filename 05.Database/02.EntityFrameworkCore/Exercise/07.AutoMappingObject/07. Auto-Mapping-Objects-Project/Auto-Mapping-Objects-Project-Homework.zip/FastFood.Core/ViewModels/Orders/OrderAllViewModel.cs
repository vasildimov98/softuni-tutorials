﻿namespace FastFood.Core.ViewModels.Orders
{
    public class OrderAllViewModel
    {
        public string Customer { get; set; }

        public string Employee { get; set; }

        public string DateTime { get; set; }
    }
}
