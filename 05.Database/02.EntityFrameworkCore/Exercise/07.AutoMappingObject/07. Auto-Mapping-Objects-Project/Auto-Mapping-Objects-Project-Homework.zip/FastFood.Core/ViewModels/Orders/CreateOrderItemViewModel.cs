﻿namespace FastFood.Core.ViewModels.Orders
{
    public class CreateOrderItemViewModel
    {
        public int Id { get; set; }

        public string Name { get; set; }
    }
}
