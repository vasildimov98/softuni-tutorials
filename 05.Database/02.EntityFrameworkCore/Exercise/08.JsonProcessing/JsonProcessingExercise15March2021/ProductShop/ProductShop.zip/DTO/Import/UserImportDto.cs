﻿namespace ProductShop.DTO.Import
{
    public class UserImportDto
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int? Age { get; set; }
    }

}
