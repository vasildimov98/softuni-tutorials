﻿namespace CarDealer.DTO.Import
{
    public class SaleImportDto
    {
        public int CarId { get; set; }

        public int CustomerId { get; set; }

        public decimal Discount { get; set; }
    }
}
