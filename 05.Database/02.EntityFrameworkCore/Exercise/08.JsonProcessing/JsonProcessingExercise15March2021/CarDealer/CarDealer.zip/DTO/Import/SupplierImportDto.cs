﻿namespace CarDealer.DTO.Import
{
    public class SupplierImportDto
    {
        public string Name { get; set; }

        public bool IsImporter { get; set; }
    }

}
