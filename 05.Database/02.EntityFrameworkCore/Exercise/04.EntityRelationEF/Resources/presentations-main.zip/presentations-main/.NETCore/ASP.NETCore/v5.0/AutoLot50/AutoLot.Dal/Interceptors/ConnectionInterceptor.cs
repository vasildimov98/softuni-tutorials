﻿// Copyright Information
// ==================================
// AutoLot - AutoLot.Dal - ConnectionInterceptor.cs
// All samples copyright Philip Japikse
// http://www.skimedic.com 2020/12/13
// ==================================

using Microsoft.EntityFrameworkCore.Diagnostics;

namespace AutoLot.Dal.Interceptors
{
    public class ConnectionInterceptor : DbConnectionInterceptor
    {

    }
}