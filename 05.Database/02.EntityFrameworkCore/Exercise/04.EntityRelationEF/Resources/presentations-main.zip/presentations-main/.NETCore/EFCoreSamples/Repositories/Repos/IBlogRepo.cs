﻿using Repositories.Models;
using Repositories.Repos.Base;

namespace Repositories.Repos
{
    public interface IBlogRepo : IRepo<Blog>
    {

    }
}
