﻿namespace FromSQLDbQuery.Models
{
    public class ShortBlogQuery
    {
        public int BlogId { get; set; }
        public string Url { get; set; }
    }
}