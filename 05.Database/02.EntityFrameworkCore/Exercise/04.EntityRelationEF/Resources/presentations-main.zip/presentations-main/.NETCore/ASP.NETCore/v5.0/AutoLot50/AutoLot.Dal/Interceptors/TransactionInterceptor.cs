﻿// Copyright Information
// ==================================
// AutoLot - AutoLot.Dal - TransactionInterceptor.cs
// All samples copyright Philip Japikse
// http://www.skimedic.com 2020/12/13
// ==================================

using Microsoft.EntityFrameworkCore.Diagnostics;

namespace AutoLot.Dal.Interceptors
{
    public class TransactionInterceptor : DbTransactionInterceptor
    {

    }
}