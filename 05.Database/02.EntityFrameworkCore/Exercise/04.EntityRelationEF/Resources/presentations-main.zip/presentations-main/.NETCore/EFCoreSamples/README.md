# Performance sample prerequisite

For the performance sample, please restore the Adventureworks 2014 sample database, 
downloadable from here: [https://msftdbprodsamples.codeplex.com/releases/view/125550](https://msftdbprodsamples.codeplex.com/releases/view/125550)
