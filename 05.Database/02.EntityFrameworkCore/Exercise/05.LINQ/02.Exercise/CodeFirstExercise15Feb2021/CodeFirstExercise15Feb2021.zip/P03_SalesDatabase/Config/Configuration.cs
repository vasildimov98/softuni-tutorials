﻿namespace P03_SalesDatabase.Config
{
    public static class Configuration
    {
        public const string CONFIGURATION_TEXT = "Server=.;Database=Sales;Integrated Security=true";
    }
}
