﻿namespace VaporStore.Data.Models.Enums
{
    public enum CardType
    {
        Debit,
        Credit
    }
}
