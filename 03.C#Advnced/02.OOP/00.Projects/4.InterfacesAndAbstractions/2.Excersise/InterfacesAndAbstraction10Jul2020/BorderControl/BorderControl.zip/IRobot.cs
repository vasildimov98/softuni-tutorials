﻿namespace BorderControl
{
    public interface IRobot : IIdentifiable
    {
        string Model { get; }
    }
}
