﻿namespace BorderControl
{
    public interface ICitizen : IIdentifiable
    {
        string Name { get; }
        int Age { get; }
    }
}
