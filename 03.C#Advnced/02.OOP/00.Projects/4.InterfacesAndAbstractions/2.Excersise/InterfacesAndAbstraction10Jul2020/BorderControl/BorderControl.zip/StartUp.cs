﻿namespace BorderControl
{
    using System;
    using System.Linq;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;

    public class StartUp
    {
        public static void Main()
        {
            var citizens = new Collection<IIdentifiable>();

            string command;
            while ((command = Console.ReadLine()) != "End")
            {
                var args = command
                 .Split(' ', StringSplitOptions.RemoveEmptyEntries)
                 .ToArray();

                if (args.Length == 3)
                {
                    var name = args[0];
                    var age = int.Parse(args[1]);
                    var id = args[2];

                    var citizen = new Citizen(name, age, id);

                    citizens.Add(citizen);
                }
                else
                {
                    var model = args[0];
                    var id = args[1];

                    var robot = new Robot(model, id);

                    citizens.Add(robot);
                }
            }

            var lastCommand = Console.ReadLine();

            Console.WriteLine(string.Join(Environment.NewLine, citizens
                .Where(c => c.Id.EndsWith(lastCommand))));
        }
    }
}
