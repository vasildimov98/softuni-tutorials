﻿namespace P02.Raiding.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
