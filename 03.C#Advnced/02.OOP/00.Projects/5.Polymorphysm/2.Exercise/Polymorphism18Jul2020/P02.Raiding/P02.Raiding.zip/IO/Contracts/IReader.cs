﻿namespace P02.Raiding.IO.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}
