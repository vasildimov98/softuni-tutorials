﻿//namespace Stealer
//{
using System;
using System.Text;
using System.Linq;
using System.Reflection;

public class Spy
{
    public string StealFieldInfo(string nameOfClass, params string[] namesOfField)
    {
        var sb = new StringBuilder();

        var type = Type.GetType(nameOfClass);
        var fields = type.GetFields(
            BindingFlags.Public
            | BindingFlags.NonPublic
            | BindingFlags.Instance
            | BindingFlags.Static)
            .Where(fl => namesOfField.Contains(fl.Name));

        var instance = Activator.CreateInstance(type, new object[0]);

        sb.AppendLine($"Class under investigation: {type}");
        foreach (var field in fields)
        {
            sb.AppendLine($"{field.Name} = {field.GetValue(instance)}");
        }
        return sb.ToString().TrimEnd();
    }
}
//}
