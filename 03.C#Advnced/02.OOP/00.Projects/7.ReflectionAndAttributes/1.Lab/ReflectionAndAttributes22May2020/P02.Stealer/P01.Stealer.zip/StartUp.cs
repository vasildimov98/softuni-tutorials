﻿//namespace Stealer
//{
    using System;
    public class StartUp
    {
        public static void Main()
        {
            var spy = new Spy();

            var result = spy.StealFieldInfo(typeof(Hacker).FullName, "username", "password");

            Console.WriteLine(result);
        }
    }
//}
