﻿namespace CustomStack
{
    using System;
    using System.Collections.Concurrent;
    using System.Collections.Generic;

    public class StartUp
    {
        public static void Main()
        {
            var stack = new StackOfStrings();

            Console.WriteLine(stack.IsEmpty());

            stack.AddRange(new List<string> { "1", "2", "3" });
            stack.AddRange(new string[] { "4", "5", "6" });

            foreach (var elem in stack)
            {
                Console.WriteLine(elem);
            }

            Console.WriteLine(stack.IsEmpty());
        }
    }
}
