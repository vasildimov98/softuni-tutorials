﻿namespace Farm
{
    using System;
    public class Cat : Animal
    {
        public void Meow()
        {
            Console.WriteLine("meowing…");
        }
    }
}
