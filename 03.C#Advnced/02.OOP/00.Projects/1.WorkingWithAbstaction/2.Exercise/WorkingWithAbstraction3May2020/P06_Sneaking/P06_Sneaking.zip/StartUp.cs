﻿namespace P06_Sneaking
{
    using System;
    using System.Collections.Generic;

    public class StartUp
    {
        public static void Main()
        {
            var engine = new Engine();

            engine.RunStartUp();
        }
    }
}
