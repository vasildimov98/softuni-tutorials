﻿namespace Tests
{
    using NUnit.Framework;
    using System;

    [TestFixture]
    public class AxeTests
    {
        [Test]
        public void AxeShouldLoseDurabilityAfterAttack()
        {
            //Arrange
            var axe = new Axe(10, 10);
            var dummy = new Dummy(10, 10);

            //Act
            axe.Attack(dummy);

            //Assert
            Assert.That(axe.DurabilityPoints, Is.EqualTo(9));
        }
        [Test]
        public void AxeShouldThrowInvalidOperationExeptionIfItsBroken()
        {
            //Arrange
            var axe = new Axe(10, 0);
            var dummy = new Dummy(10, 10);

            //Assert
            Assert
                 .That(() => axe.Attack(dummy),
                 Throws.InvalidOperationException //Act
                 .With.Message.EqualTo("Axe is broken."));
        }
    }
}
