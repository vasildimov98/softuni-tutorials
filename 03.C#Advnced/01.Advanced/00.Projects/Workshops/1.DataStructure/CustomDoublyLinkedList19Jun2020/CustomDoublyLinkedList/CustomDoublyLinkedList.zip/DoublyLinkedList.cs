﻿using System;

namespace CustomDoublyLinkedList
{
    /// <summary>
    /// A collection of ListNodes
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class DoublyLinkedList<T>
    {
        private const int EMPTY_COLLECTION = 0;

        /// <summary>
        /// The first node (element) in the collection
        /// </summary>
        private ListNode<T> head;

        /// <summary>
        /// The last node (element) in the collection
        /// </summary>
        private ListNode<T> tail;

        /// <summary>
        /// Empty constructor 
        /// </summary>
        public DoublyLinkedList()
        {

        }

        /// <summary>
        /// Return the count of elements in the collection
        /// </summary>
        public int Count { get; private set; }

        /// <summary>
        /// Adds an element at the beginning of the collection (head)
        /// </summary>
        /// <param name="element"></param>
        public void AddFirst(T element)
        {
            var newHead = new ListNode<T>(element);

            if (this.Count == EMPTY_COLLECTION)
            {
                this.head = this.tail = newHead;
            }
            else
            {
                newHead.NextNode = this.head;
                this.head.PreviousNode = newHead;
                this.head = newHead;
            }

            this.Count++;
        }

        /// <summary>
        /// Adds an element at the end of the collection (tail)
        /// </summary>
        /// <param name="element"></param>
        public void AddLast(T element)
        {
            var newTail = new ListNode<T>(element);

            if (this.Count == EMPTY_COLLECTION)
            {
                this.tail = this.head = newTail;
            }
            else
            {
                newTail.PreviousNode = this.tail;
                this.tail.NextNode = newTail;
                this.tail = newTail;
            }

            this.Count++;
        }

        /// <summary>
        /// Removes the element (head) at the beginning of the collection
        /// </summary>
        /// <returns>Removed element or throws Exception</returns>
        public T RemoveFirst()
        {
            if (this.Count == 0)
            {
                throw new InvalidOperationException($"The list is empty!");
            }

            var removed = this.head.Value;
            if (this.Count == 1)
            {
                this.head = this.tail = null;
            }
            else
            {
                this.head = this.head.NextNode;
                this.head.PreviousNode = null;
            }

            this.Count--;
            return removed;
        }

        /// <summary>
        /// Removes the element (tail) at the end of the collection
        /// </summary>
        /// <returns>Removed element or throws Exception</returns>
        public T RemoveLast()
        {
            if (this.Count == 0)
            {
                throw new InvalidOperationException("The list is empty!");
            }

            var removedElement = this.tail.Value;
            if (this.Count == 1)
            {
                this.tail = this.head = null;
            }
            else
            {
                this.tail = this.tail.PreviousNode;
                this.tail.NextNode = null;
            }

            this.Count--;
            return removedElement;
        }

        /// <summary>
        /// Goes through the collection and executes a given action
        /// </summary>
        /// <param name="action"></param>
        public void ForEach(Action<T> action)
        {
            var currentNode = this.head;
            while (currentNode != null)
            {
                action(currentNode.Value);

                currentNode = currentNode.NextNode;
            }
        }

        /// <summary>
        /// Returns the collection as an array
        /// </summary>
        /// <returns></returns>
        public T[] ToArray()
        {
            var arr = new T[this.Count];
            var index = 0;

            var currentNode = this.head;
            while (currentNode != null)
            {
                arr[index++] = currentNode.Value;

                currentNode = currentNode.NextNode;
            }

            return arr;
        }
    }
}
