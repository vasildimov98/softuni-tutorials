﻿namespace CustomDoublyLinkedList
{
    using System;
    using System.Runtime.CompilerServices;

    public class StartUp
    {
        private static DoublyLinkedList<int> myDoybleLinkedList;
        public static void Main()
        {
            myDoybleLinkedList = new DoublyLinkedList<int>();

            myDoybleLinkedList.AddLast(10);
            myDoybleLinkedList.AddLast(20);

            Console.WriteLine(myDoybleLinkedList.RemoveFirst());
            Console.WriteLine(myDoybleLinkedList.RemoveFirst());

            try
            {
                myDoybleLinkedList.RemoveFirst();
            }
            catch (InvalidOperationException ioe)
            {
                Console.WriteLine(ioe.Message);
            }

            var elementsToAdd = 10;
            AddLastElementsToCollection(elementsToAdd);

            myDoybleLinkedList
                .ForEach(Console.WriteLine);

            var arr = myDoybleLinkedList.ToArray();

            Console.WriteLine(arr[6]);

            var elementsToRemoved = 11;

            try
            {
                RemoveElementsFromTheCollection(elementsToRemoved);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        private static void RemoveElementsFromTheCollection(int count)
        {
            for (int i = 1; i <= count; i++)
            {
                myDoybleLinkedList.RemoveLast();
            }
        }

        private static void AddFirstElementsToCollection(int count)
        {
            for (int i = 1; i <= count; i++)
            {
                myDoybleLinkedList.AddFirst(10 * i);
            }
        }

        private static void AddLastElementsToCollection(int count)
        {
            for (int i = 1; i <= count; i++)
            {
                myDoybleLinkedList.AddLast(10 * i);
            }
        }
    }
}
