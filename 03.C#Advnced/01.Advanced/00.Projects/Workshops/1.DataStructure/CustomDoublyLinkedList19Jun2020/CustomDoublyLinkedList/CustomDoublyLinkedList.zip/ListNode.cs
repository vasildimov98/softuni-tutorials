﻿namespace CustomDoublyLinkedList
{
    /// <summary>
    /// A generic Node, which holdes value, NextNode, PrevNode
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class ListNode<T>
    {
        /// <summary>
        /// Instantiate new Node with current value;
        /// </summary>
        /// <param name="value"></param>
        public ListNode(T value)
        {
            this.Value = value;
        }

        /// <summary>
        /// The value of the current Node
        /// </summary>
        public T Value { get; set; }

        /// <summary>
        /// The reference to the next node in the memory
        /// </summary>
        public ListNode<T> NextNode { get; set; }
        /// <summary>
        /// The reference to the previous node in the memory
        /// </summary>
        public ListNode<T> PreviousNode { get; set; }
    }
}
