﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _10._Radioactive_Mutant_Vampire_Bunnies
{
    class Program
    {
        static void Main(string[] args)
        {
            var dimensions = Console
                .ReadLine()
                .Split(' ', StringSplitOptions.RemoveEmptyEntries)
                .Select(int.Parse)
                .ToArray();

            var rows = dimensions[0];
            var cols = dimensions[1];

            var matrix = new char[rows, cols];
            var bunnies = new Queue<int[]>();

            var playerRowIndex = 0;
            var playerColIndex = 0;

            for (int row = 0; row < rows; row++)
            {
                var data = Console
                    .ReadLine()
                    .ToCharArray();

                for (int col = 0; col < cols; col++)
                {
                    matrix[row, col] = data[col];

                    if (data[col] == 'B')
                    {
                        var arr = new int[2] { row, col };
                        bunnies.Enqueue(arr);
                    }
                    else if (data[col] == 'P')
                    {
                        playerRowIndex = row;
                        playerColIndex = col;
                    }
                }
            }

            var movements = Console.ReadLine();
            var stepOnBunny = false;
            var stepOutOfField = false;

            foreach (var move in movements)
            {
                var currPlayerRowIndex = playerRowIndex;
                var currPlayerColIndex = playerColIndex;

                switch (move)
                {
                    case 'L':
                        currPlayerColIndex--;
                        break;
                    case 'R':
                        currPlayerColIndex++;
                        break;
                    case 'U':
                        currPlayerRowIndex--;
                        break;
                    case 'D':
                        currPlayerRowIndex++;
                        break;
                }

                if (ValidateCell(currPlayerRowIndex, currPlayerColIndex, matrix))
                {
                    matrix[playerRowIndex, playerColIndex] = '.';

                    playerRowIndex = currPlayerRowIndex;
                    playerColIndex = currPlayerColIndex;

                    if (!LookForBunny(playerRowIndex, playerColIndex, matrix))
                    {
                        matrix[playerRowIndex, playerColIndex] = 'P';
                    }
                    else
                    {
                        stepOnBunny = true;
                    }
                }
                else
                {
                    stepOutOfField = true;
                    matrix[playerRowIndex, playerColIndex] = '.';
                }

                int count = bunnies.Count;
                for (int i = 0; i < count; i++)
                {
                    var currBunnie = bunnies.Dequeue();
                    var bunnieRow = currBunnie[0];
                    var bunnieCol = currBunnie[1];

                    //up
                    if (ValidateCell(bunnieRow - 1, bunnieCol, matrix))
                    {
                        if (LookForPlayer(bunnieRow - 1, bunnieCol, matrix))
                        {
                            stepOnBunny = true;
                        }
                        matrix[bunnieRow - 1, bunnieCol] = 'B';
                        var bunnie = new int[2] { bunnieRow - 1, bunnieCol };
                        bunnies.Enqueue(bunnie);
                    }
                    //down
                    if (ValidateCell(bunnieRow + 1, bunnieCol, matrix))
                    {
                        if (LookForPlayer(bunnieRow + 1, bunnieCol, matrix))
                        {
                            stepOnBunny = true;
                        }
                        matrix[bunnieRow + 1, bunnieCol] = 'B';
                        var bunnie = new int[2] { bunnieRow + 1, bunnieCol };
                        bunnies.Enqueue(bunnie);
                    }
                    //right
                    if (ValidateCell(bunnieRow, bunnieCol + 1, matrix))
                    {
                        if (LookForPlayer(bunnieRow, bunnieCol + 1, matrix))
                        {
                            stepOnBunny = true;
                        }
                        matrix[bunnieRow, bunnieCol + 1] = 'B';
                        var bunnie = new int[2] { bunnieRow, bunnieCol + 1 };
                        bunnies.Enqueue(bunnie);
                    }
                    //left
                    if (ValidateCell(bunnieRow, bunnieCol - 1, matrix))
                    {
                        if (LookForPlayer(bunnieRow, bunnieCol - 1, matrix))
                        {
                            stepOnBunny = true;
                        }
                        matrix[bunnieRow, bunnieCol - 1] = 'B';
                        var bunnie = new int[2] { bunnieRow, bunnieCol - 1 };
                        bunnies.Enqueue(bunnie);
                    }
                }

                if (stepOutOfField || stepOnBunny)
                {
                    break;
                }
            }

            PrintMatrix(matrix);
            if (stepOutOfField)
            {
                Console.WriteLine($"won: {playerRowIndex} {playerColIndex}");
            }
            else if (stepOnBunny)
            {
                Console.WriteLine($"dead: {playerRowIndex} {playerColIndex}");
            }
        }
        static void PrintMatrix(char[,] matrix)
        {
            for (int row = 0; row < matrix.GetLength(0); row++)
            {
                for (int col = 0; col < matrix.GetLength(1); col++)
                {
                    Console.Write(matrix[row, col]);
                }
                Console.WriteLine();
            }
        }
        static bool ValidateCell(int row, int col, char[,] matrix)
        {
            if (row < 0
                || row >= matrix.GetLength(0)
                || col < 0
                || col >= matrix.GetLength(1))
            {
                return false;
            }

            return true;
        }
        static bool LookForBunny(int row, int col, char[,] matrix)
        {
            if (matrix[row, col] != 'B')
            {
                return false;
            }
            return true;
        }
        static bool LookForPlayer(int row, int col, char[,] matrix)
        {
            if (matrix[row, col] != 'P')
            {
                return false;
            }
            return true;
        }
    }
}
