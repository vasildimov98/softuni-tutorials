﻿using System;

namespace CarManufacturer
{
    public class StartUp
    {
        static void Main()
        {
            // 1. Car and 2. CarExtension

            //var car = new Car();

            //car.Make = "VW";
            //car.Model = "MK3";
            //car.Year = 1992;
            //car.FuelQuantity = 200;
            //car.FuelConsumption = 200;
            //car.Drive(1);
            //car.Drive(1);
            //Console.WriteLine(car.WhoAmI());

            //3. Car Constructors

            var make = Console.ReadLine();
            var model = Console.ReadLine();
            var year = int.Parse(Console.ReadLine());
            double fuelQuantity = double.Parse(Console.ReadLine());
            double fuelConsumption = double.Parse(Console.ReadLine());

            var firstCar = new Car();
            var secondCar = new Car(make, model, year);
            var thirdCar = new Car(make, model, year, fuelQuantity, fuelConsumption);

            Console.WriteLine(firstCar.WhoAmI());
            Console.WriteLine("....................................................");
            Console.WriteLine(secondCar.WhoAmI());
            Console.WriteLine("....................................................");
            Console.WriteLine(thirdCar.WhoAmI());
        }
    }
}
