﻿namespace DefiningClasses
{
    using System;
    public class StartUp
    {
        public static void Main()
        {
            var firstPerson = new Person();

            var secondPerson = new Person(18);

            var thirdPerson = new Person("Stamat", 43);

            Console.WriteLine($"Name: {firstPerson.Name}\nAge: {firstPerson.Age}");
            Console.WriteLine($"Name: {secondPerson.Name}\nAge: {secondPerson.Age}");
            Console.WriteLine($"Name: {thirdPerson.Name}\nAge: {thirdPerson.Age}");
        }
    }
}
