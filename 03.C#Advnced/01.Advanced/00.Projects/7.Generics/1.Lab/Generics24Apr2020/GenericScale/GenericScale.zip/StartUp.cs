﻿using System;

namespace GenericScale
{
    public class StartUp
    {
        static void Main()
        {
            Console.WriteLine(new EqualityScale<int>(2, 3).AreEqual());
        }
    }
}
