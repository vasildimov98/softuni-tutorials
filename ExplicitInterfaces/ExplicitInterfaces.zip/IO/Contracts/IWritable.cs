﻿namespace ExplicitInterfaces.IO.Contracts
{
    public interface IWritable
    {
        void WriteLine(string text);
    }
}
