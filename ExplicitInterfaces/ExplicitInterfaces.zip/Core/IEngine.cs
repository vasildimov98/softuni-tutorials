﻿namespace ExplicitInterfaces.Core
{
    public interface IEngine
    {
        void Run();
    }
}
