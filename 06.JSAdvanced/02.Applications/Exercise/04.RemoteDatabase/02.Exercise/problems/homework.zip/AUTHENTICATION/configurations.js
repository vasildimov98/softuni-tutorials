var firebaseConfig = {
    apiKey: "AIzaSyAIEDdoH7-KqODVlna_K7RK5vdaKSTVpLU",
    authDomain: "my-books-64fa3.firebaseapp.com",
    databaseURL: "https://my-books-64fa3.firebaseio.com",
    projectId: "my-books-64fa3",
    storageBucket: "my-books-64fa3.appspot.com",
    messagingSenderId: "397237543332",
    appId: "1:397237543332:web:2184190fb39803523e2131",
    measurementId: "G-DMWVXGEFZP"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
