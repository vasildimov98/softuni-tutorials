﻿namespace CollectionHierarchy.Contracts
{
    public interface IAddable
    {
        int Add(string word);
    }
}
