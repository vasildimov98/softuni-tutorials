﻿namespace CollectionHierarchy.Contracts
{
    public interface IUsable
    {
        int Used { get; }
    }
}
