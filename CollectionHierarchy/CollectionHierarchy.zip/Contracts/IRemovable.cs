﻿namespace CollectionHierarchy.Contracts
{
    public interface IRemovable
    {
        string Remove();
    }
}
