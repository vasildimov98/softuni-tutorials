﻿namespace CollectionHierarchy.Core
{
    public interface IEngine
    {
        void Run();
    }
}
