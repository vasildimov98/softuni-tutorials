﻿using PlayersAndMonsters.Knight;

namespace PlayersAndMonsters
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var someHero = new DarkKnight("Baj Pesho", 1312);

            System.Console.WriteLine(someHero);
        }
    }
}