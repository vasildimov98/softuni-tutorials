﻿namespace Animals
{
    public class Kittens : Cat
    {
        private const string GENDER = "Female";

        public Kittens(string name, int age)
            : base(name, age, GENDER)
        {

        }

        public override string ProduceSound()
        {
            return "Meow";
        }
    }
}
