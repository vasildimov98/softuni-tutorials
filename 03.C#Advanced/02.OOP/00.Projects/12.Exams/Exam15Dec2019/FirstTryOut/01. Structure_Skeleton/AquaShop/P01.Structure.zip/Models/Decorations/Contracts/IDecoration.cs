﻿namespace AquaShop.Models.Decorations.Contracts
{
    public interface IDecoration
    {
        int Comfort { get; }

        decimal Price { get; }
    }
}
