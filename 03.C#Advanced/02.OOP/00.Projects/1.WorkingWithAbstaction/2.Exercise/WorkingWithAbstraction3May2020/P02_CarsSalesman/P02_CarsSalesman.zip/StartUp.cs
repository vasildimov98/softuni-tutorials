﻿namespace P02_CarsSalesman
{
    class StartUp
    {
        static void Main()
        {
            var engine = new ProgramEngine();
            engine.StartProgram();
        }
    }

}
