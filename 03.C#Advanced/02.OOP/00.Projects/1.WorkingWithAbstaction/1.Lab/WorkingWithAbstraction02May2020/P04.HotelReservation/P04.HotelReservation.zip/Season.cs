﻿namespace P04.HotelReservation
{
    public enum Season
    {
        Spring = 2,
        Summer = 4,
        Autumn = 1,
        Winter = 3
    }
}
