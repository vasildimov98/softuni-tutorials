﻿namespace P04.HotelReservation
{
    public enum Discount
    {
        None,
        SecondVisit = 10,
        VIP = 20
    }
}
