﻿namespace P03.StudentSystem
{
    public interface IInputOutputProvider
    {
        string GetInput();
        void ShowOutput(string text);
    }
}
