﻿namespace P05.FootballTeamGenerator
{
    using P05.FootballTeamGenerator.Core;
    using System;
    public class StartUp
    {
        public static void Main()
        {
            var engine = new Engine();

            engine.Run();
        }
    }
}
