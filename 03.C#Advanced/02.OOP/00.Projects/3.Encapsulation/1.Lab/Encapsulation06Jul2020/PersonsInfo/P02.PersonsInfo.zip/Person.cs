﻿namespace PersonsInfo
{
    public class Person
    {
        private const int THIRTY_YEARS_OLD_AGE = 30;

        public Person(string firstName, string lastName, int age, decimal salary)
        {
            this.FirstName = firstName;
            this.LastName = lastName;
            this.Age = age;
            this.Salary = salary;
        }

        public string FirstName { get; }
        public string LastName { get; }
        public int Age { get; }
        public decimal Salary { get; private set; }

        public void IncreaseSalary(decimal percentage)
        {
            var devider = 100;

            if (this.Age < THIRTY_YEARS_OLD_AGE)
            {
                devider *= 2;
            }

            this.Salary += Salary * percentage / devider;
        }
        public override string ToString()
        {
            return $"{this.FirstName} {this.LastName} receives {this.Salary:F2} leva.";
        }
    }
}
