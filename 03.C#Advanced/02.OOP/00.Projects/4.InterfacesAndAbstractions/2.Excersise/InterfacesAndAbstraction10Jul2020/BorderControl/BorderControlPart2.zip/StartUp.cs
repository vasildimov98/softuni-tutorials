﻿namespace BorderControl
{
    using System;
    using System.Linq;
    using System.Collections.ObjectModel;

    public class StartUp
    {
        public static void Main()
        {
            var citizens = new Collection<IBirthable>();

            string command;
            while ((command = Console.ReadLine()) != "End")
            {
                var args = command
                 .Split(' ', StringSplitOptions.RemoveEmptyEntries)
                 .ToArray();

                var action = args[0];

                if (action == "Robot")
                {
                    continue;
                }

                if (action == "Citizen")
                {
                    var name = args[1];
                    var age = int.Parse(args[2]);
                    var id = args[3];
                    var birthdate = args[4];

                    var citizen = new Citizen(name, age, id, birthdate);

                    citizens.Add(citizen);
                }
                else if (action == "Pet")
                {
                    var name = args[1];
                    var birthdate = args[2];

                    var pet = new Pet(name, birthdate);

                    citizens.Add(pet);
                }
            }

            var lastCommand = Console.ReadLine();

            if (citizens.Any())
            {
                Console.WriteLine(string.Join(Environment.NewLine, citizens
               .Where(c => c.Birthdate.EndsWith(lastCommand))));
            }
        }
    }
}
