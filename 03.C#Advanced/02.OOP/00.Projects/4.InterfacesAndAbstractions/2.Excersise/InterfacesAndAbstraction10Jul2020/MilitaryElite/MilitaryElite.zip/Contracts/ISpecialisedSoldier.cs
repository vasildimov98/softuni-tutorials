﻿namespace MilitaryElite.Contracts
{
    using Enumerators;
    public interface ISpecialisedSoldier
    {
        Corps Corps { get; }
    }
}
