﻿namespace MilitaryElite.Contracts
{
    public interface IPrivate
    {
        decimal Salary { get; }
    }
}
