﻿namespace Telephony.Models.Contracts
{
    public interface IBrowsable
    {
        string Browse(string URL);
    }
}
