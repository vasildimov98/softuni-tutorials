﻿namespace Telephony.Models.Contracts
{
    public interface ICallable
    {
        string Call(string number);
    }
}
