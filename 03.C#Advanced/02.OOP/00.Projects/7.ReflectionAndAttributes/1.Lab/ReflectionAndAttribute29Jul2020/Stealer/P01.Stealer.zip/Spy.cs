﻿namespace Stealer
{
    using System;
    using System.Text;
    using System.Reflection;
    using System.Linq;

    public class Spy
    {
        public string StealFieldInfo(string nameOfTheClass, params string[] filedsName)
        {
            var sb = new StringBuilder();
            sb.AppendLine($"Class under investigation: {nameOfTheClass}");

            var classType = Type.GetType(nameOfTheClass);

            var fieldsInfo = classType.GetFields(BindingFlags.Public | BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Static);

            var instantiatedClass = Activator.CreateInstance(classType);

            foreach (var field in fieldsInfo.Where(f => filedsName.Contains(f.Name)))
            {
                sb.AppendLine($"{field.Name} = {field.GetValue(instantiatedClass)}");
            }

            return sb.ToString().TrimEnd();
        }
    }
}
