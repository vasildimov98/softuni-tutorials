﻿//namespace P03.Attribute
//{
using System;

[Author("Ventsi")]
public class StartUp
{
    [Author("Gosho")]
    public static void Main()
    {
        Console.WriteLine("Hello World!");
    }
}
//}
