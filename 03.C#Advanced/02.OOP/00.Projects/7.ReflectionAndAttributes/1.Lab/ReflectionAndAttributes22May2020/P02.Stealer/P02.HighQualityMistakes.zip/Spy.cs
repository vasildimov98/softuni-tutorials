﻿//namespace Stealer
//{
using System;
using System.Text;
using System.Linq;
using System.Reflection;

public class Spy
{
    public string StealFieldInfo(string nameOfClass, params string[] namesOfField)
    {
        var sb = new StringBuilder();

        var type = Type.GetType(nameOfClass);
        var fields = type.GetFields(
            BindingFlags.Public
            | BindingFlags.NonPublic
            | BindingFlags.Instance
            | BindingFlags.Static)
            .Where(fl => namesOfField.Contains(fl.Name));

        var instance = Activator.CreateInstance(type, new object[0]);

        sb.AppendLine($"Class under investigation: {type}");
        foreach (var field in fields)
        {
            sb.AppendLine($"{field.Name} = {field.GetValue(instance)}");
        }
        return sb.ToString().TrimEnd();
    }

    public string AnalyzeAcessModifiers(string className)
    {
        var sb = new StringBuilder();

        var typeClass = Type.GetType(className);
        var classField = typeClass.GetFields(BindingFlags.Public | BindingFlags.Instance | BindingFlags.Static);
        var publicMethods = typeClass.GetMethods(BindingFlags.Public | BindingFlags.Instance);
        var nonPublicMethods = typeClass.GetMethods(BindingFlags.NonPublic | BindingFlags.Instance);

        foreach (var field in classField)
        {
            sb.AppendLine($"{field.Name} must be private!");
        }
        foreach (var privateMethod in nonPublicMethods.Where(get => get.Name.StartsWith("get")))
        {
            sb.AppendLine($"{privateMethod.Name} have to be public!");
        }
        foreach (var publicMethod in publicMethods.Where(set => set.Name.StartsWith("set")))
        {
            sb.AppendLine($"{publicMethod.Name} have to be private!");
        }

        return sb.ToString().TrimEnd();
    }
}
//}
