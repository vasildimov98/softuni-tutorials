﻿namespace ValidationAttributes
{
    using System;
    using ValidationAttributes.Models;
    public class StartUp
    {
        public static void Main()
        {
            var person = new Person
             (
                 "Peter Petrov",
                 10000
             );

            bool isValidEntity = Validator.IsValid(person);

            Console.WriteLine(isValidEntity);
        }
    }
}
