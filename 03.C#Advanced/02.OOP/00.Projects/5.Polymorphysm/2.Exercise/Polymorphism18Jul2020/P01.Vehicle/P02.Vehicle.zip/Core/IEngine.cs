﻿namespace P01.Vehicle.Core
{
    public interface IEngine
    {
        void Run();
    }
}
