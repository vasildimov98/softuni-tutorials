﻿namespace P01.Vehicle.Models
{
    using System;

    using P01.Vehicle.Models.Contracts;

    public abstract class Vehicle : IVehicle
    {
        public Vehicle(double fuelQuantity, double fuelConsumption)
        {
            this.FuelQuantity = fuelQuantity;
            this.FuelConsumption = fuelConsumption;
        }

        public double FuelQuantity { get; protected set; }
        public virtual double FuelConsumption { get; }

        public string Drive(double distance)
        {
            var neededFuel = this.FuelConsumption * distance;

            if (neededFuel <= this.FuelQuantity)
            {
                this.FuelQuantity -= neededFuel;
                return $"{this.GetType().Name} travelled {distance} km";
            }
            else 
            {
                return $"{this.GetType().Name} needs refueling";
            }
        }
        public virtual void Refuel(double amountOfFuel)
        {
            this.FuelQuantity += amountOfFuel;
        }
        public override string ToString()
        {
            return $"{this.GetType().Name}: {Math.Round(this.FuelQuantity, 2, MidpointRounding.AwayFromZero):F2}";
        }
    }
}
