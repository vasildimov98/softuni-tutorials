﻿namespace P01.Vehicle.Core
{
    using System;
    using System.Linq;

    using Models.Contracts;
    using P01.Vehicle.Models;

    public class Engine : IEngine
    {
        private IVehicle car;
        private IVehicle truck;
        public void Run()
        {
            this.InstanciateObject();
            this.SeekAction();
            this.PrintResult();
        }

        private void PrintResult()
        {
            Console.WriteLine(car);
            Console.WriteLine(truck);
        }

        private void SeekAction()
        {
            var numberOfCommands = int.Parse(Console.ReadLine());
            for (int i = 0; i < numberOfCommands; i++)
            {
                var actionArgs = Console
                    .ReadLine()
                    .Split(' ', StringSplitOptions.RemoveEmptyEntries);

                var action = actionArgs[0] + ' ' + actionArgs[1];
                var methodParameter = double.Parse(actionArgs[2]);

                this.ProceedAction(action, methodParameter);
            }
        }

        private void ProceedAction(string action, double methodParameter)
        {
            if (action == "Drive Car")
            {
                Console.WriteLine(car.Drive(methodParameter));
            }
            else if (action == "Drive Truck")
            {
                Console.WriteLine(truck.Drive(methodParameter));
            }
            else if (action == "Refuel Car")
            {
                car.Refuel(methodParameter);
            }
            else
            {
                truck.Refuel(methodParameter);
            }
        }

        private void InstanciateObject()
        {
            var carArgs = Console
                .ReadLine()
                .Split(' ', StringSplitOptions.RemoveEmptyEntries)
                .Skip(1)
                .Select(double.Parse)
                .ToArray();

            var carFuelQuantity = carArgs[0];
            var carLitersPerKm = carArgs[1];

            this.car = new Car(carFuelQuantity, carLitersPerKm);

            var truckArgs = Console
               .ReadLine()
               .Split(' ', StringSplitOptions.RemoveEmptyEntries)
               .Skip(1)
               .Select(double.Parse)
               .ToArray();

            var truckFuelQuantity = truckArgs[0];
            var truckLitersPerKm = truckArgs[1];

            this.truck = new Truck(truckFuelQuantity, truckLitersPerKm);
        }
    }
}
