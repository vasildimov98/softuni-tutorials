﻿namespace P01.Vehicle.Models
{
    public class Truck : Vehicle
    {
        private const double AIR_CONDITIONERS_CONSUMPTION = 1.6;
        private const double REFUEL_CAPACITY = 0.95;

        public Truck(double fuelQuantity, double fuelConsumption)
            : base(fuelQuantity, fuelConsumption)
        {

        }

        public override double FuelConsumption
            => base.FuelConsumption + AIR_CONDITIONERS_CONSUMPTION;

        public override void Refuel(double amountOfFuel)
        {
            base.Refuel(amountOfFuel * REFUEL_CAPACITY);
        }
    }
}
