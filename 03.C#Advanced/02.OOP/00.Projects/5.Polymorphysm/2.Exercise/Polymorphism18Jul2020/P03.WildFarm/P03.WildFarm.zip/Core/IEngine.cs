﻿namespace P03.WildFarm.Core
{
    public interface IEngine
    {
        void Run();
    }
}
