﻿namespace P03.WildFarm.IO.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}
