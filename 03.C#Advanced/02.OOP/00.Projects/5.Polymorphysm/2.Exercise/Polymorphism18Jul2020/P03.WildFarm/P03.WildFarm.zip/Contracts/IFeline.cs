﻿namespace P03.WildFarm.Contracts
{
    public interface IFeline : IMammal
    {
        string Breed { get; }
    }
}
