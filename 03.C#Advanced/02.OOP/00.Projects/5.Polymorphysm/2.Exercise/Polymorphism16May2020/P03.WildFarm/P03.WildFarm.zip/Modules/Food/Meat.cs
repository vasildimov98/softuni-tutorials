﻿namespace P03.WildFarm.Modules.Food
{
    public class Meat : Food
    {
        public Meat(int quantity)
            : base(quantity)
        {

        }
    }
}
