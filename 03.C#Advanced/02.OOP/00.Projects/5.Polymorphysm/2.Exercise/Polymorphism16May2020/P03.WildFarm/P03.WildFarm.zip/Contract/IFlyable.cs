﻿namespace P03.WildFarm.Contract
{
    public interface IFlyable : IAnimal
    {
        double WingSize { get; }
    }
}
