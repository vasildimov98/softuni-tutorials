﻿namespace P03.WildFarm.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
