﻿namespace P03.WildFarm.Contract
{
    public interface IEatable
    {
        void Eat(int quantity);
    }
}
