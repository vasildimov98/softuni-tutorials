﻿namespace P03.WildFarm.Contract
{
    public interface IFood
    {
        int Quantity { get; }
    }
}
