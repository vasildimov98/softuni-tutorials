﻿namespace P03.WildFarm.Modules.Food
{
    public class Seeds : Food
    {
        public Seeds(int quantity)
            : base(quantity)
        {

        }
    }
}
