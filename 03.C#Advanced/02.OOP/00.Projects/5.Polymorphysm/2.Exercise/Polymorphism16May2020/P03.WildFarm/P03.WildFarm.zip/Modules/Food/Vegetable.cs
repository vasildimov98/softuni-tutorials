﻿namespace P03.WildFarm.Modules.Food
{
    public class Vegetable : Food
    {
        public Vegetable(int quantity)
            : base(quantity)
        {

        }
    }
}
