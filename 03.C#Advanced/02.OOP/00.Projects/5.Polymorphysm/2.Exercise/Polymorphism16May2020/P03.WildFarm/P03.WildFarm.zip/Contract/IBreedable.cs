﻿namespace P03.WildFarm.Contract
{
    public interface IBreedable : IMammal
    {
        string Breed { get; }
    }
}
