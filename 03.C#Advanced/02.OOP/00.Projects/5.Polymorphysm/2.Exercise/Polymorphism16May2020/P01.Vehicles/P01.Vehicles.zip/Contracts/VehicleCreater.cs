﻿namespace P01.Vehicles.Contracts
{
    using System;

    using P01.Vehicles.Modules;

    public static class VehicleCreater
    {
        public static Vehicle Create(string type,
            double fuelQuantity,
            double fuelConsumption,
            double tankCapacity)
        {
            Vehicle vehicle = null;
            try
            {
                vehicle = CreateVehicle(type, fuelQuantity, fuelConsumption, tankCapacity);
            }
            catch (InvalidOperationException ioe)
            {
                throw ioe;
            }

            return vehicle;
        }

        private static Vehicle CreateVehicle(string type, double fuelQuantity, double fuelConsumption, double tankCapacity)
        {
            if (type == "Car")
            {
                return new Car(tankCapacity, fuelQuantity, fuelConsumption);
            }
            else if (type == "Truck")
            {
                return new Truck(tankCapacity, fuelQuantity, fuelConsumption);
            }
            else if (type == "Bus")
            {
                return new Bus(tankCapacity, fuelQuantity, fuelConsumption);
            }
            else
            {
                throw new ArgumentException("Type doesn't exits!");
            }
        }
    }
}
