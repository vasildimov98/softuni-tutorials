﻿namespace P01.Vehicles.Modules
{
    using System;

    using P01.Vehicles.Exeptions;

    public class Truck : Vehicle
    {
        private const double TRUCK_CONSUMPTION_INCREASE = 1.6;
        private const double TRUCK_TANK_PERCENTEGE_CAPACITY = 0.95;

        public Truck(double tankCapacity, double fuelQuantity, double fuelConsumption)
            : base(tankCapacity, fuelQuantity, fuelConsumption)
        {

        }

        public override double FuelConsumption
            => base.FuelConsumption + TRUCK_CONSUMPTION_INCREASE;

        public override void Refuel(double fuel)
        {
            base.FuelQuantity +=
                fuel * TRUCK_TANK_PERCENTEGE_CAPACITY;
        }
    }
}
