﻿namespace P01.Vehicles.Core
{
    public interface IEngine
    {
        void Run();
    }
}
