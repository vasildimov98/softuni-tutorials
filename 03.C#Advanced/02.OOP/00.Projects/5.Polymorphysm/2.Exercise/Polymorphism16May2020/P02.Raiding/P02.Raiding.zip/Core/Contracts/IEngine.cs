﻿namespace P02.Raiding.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
