﻿namespace P02.Raiding.IO.Contracts
{
    public interface IReadable
    {
        string ReadLine();
    }
}
