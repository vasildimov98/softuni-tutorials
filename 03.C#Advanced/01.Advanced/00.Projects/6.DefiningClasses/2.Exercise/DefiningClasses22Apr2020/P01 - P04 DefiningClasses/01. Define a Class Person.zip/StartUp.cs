﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main()
        {
            var pesho = new Person()
            {
                Name = "Pesho",
                Age = 20,
            };

            var gosho = new Person();

            gosho.Name = "Gosho";
            gosho.Age = 18;

            Console.WriteLine($"{pesho.Name} is {pesho.Age} years old.");
            Console.WriteLine($"{gosho.Name} is {gosho.Age} years old.");
        }
    }
}
