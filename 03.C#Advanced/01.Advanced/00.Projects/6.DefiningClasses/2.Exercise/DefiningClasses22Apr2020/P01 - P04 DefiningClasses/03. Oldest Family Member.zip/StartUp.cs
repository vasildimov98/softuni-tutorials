﻿using System;
using System.Linq;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main()
        {
            var n = int.Parse(Console.ReadLine());

            var family = new Family();
            for (int i = 0; i < n; i++)
            {
                var personArg = Console
                    .ReadLine()
                    .Split(" ", StringSplitOptions.RemoveEmptyEntries)
                    .ToArray();

                var name = personArg[0];
                var age = int.Parse(personArg[1]);

                var person = new Person(name, age);

                family.AddMember(person);
            }

            Console.WriteLine(family.GetOldestFamilyMember());
        }
    }
}
