﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main()
        {
            var pesho = new Person();

            var name = "Gosho";
            var age = 18;
            var gosho = new Person(name, age);

            Console.WriteLine($"{pesho.Name} is {pesho.Age} years old.");
            Console.WriteLine($"{gosho.Name} is {gosho.Age} years old.");
        }
    }
}
