﻿namespace DefiningClasses
{
    using System;
    public class StartUp
    {
        public static void Main()
        {
            var firstPerson = new Person();

            firstPerson.Name = "Pesho";
            firstPerson.Age = 20;

            var secondPerson = new Person()
            {
                Name = "Gosho",
                Age = 18
            };

            var thirdPerson = new Person()
            {
                Name = "Stamat",
                Age = 43
            };

            Console.WriteLine($"Name: {firstPerson.Name}\nAge: {firstPerson.Age}");
            Console.WriteLine($"Name: {secondPerson.Name}\nAge: {secondPerson.Age}");
            Console.WriteLine($"Name: {thirdPerson.Name}\nAge: {thirdPerson.Age}");
        }
    }
}
